#include "suffix_lcp.h"
#include <algorithm>
#include <iostream>
#include <vector>

std::vector<int> SuffixLCPAnalyzer::build_suffix_array(const std::string& text) {
    int n = static_cast<int>(text.size());
    std::vector<int> SA(n);
    std::vector<int> rank(n);
    std::vector<int> tmp(n);

    for (int i = 0; i < n; ++i) {
        SA[i] = i;
        rank[i] = static_cast<unsigned char>(text[i]);
    }

    for (int k = 1; k < n; k <<= 1) {
        auto compare_suffixes = [&](int i, int j) {
            if (rank[i] != rank[j]) return rank[i] < rank[j];
            int ri = (i + k < n) ? rank[i + k] : -1;
            int rj = (j + k < n) ? rank[j + k] : -1;
            return ri < rj;
        };

        std::sort(SA.begin(), SA.end(), compare_suffixes);

        tmp[SA[0]] = 0;
        for (int i = 1; i < n; ++i) {
            tmp[SA[i]] = tmp[SA[i - 1]] + (compare_suffixes(SA[i - 1], SA[i]) ? 1 : 0);
        }
        rank = tmp;
        if (rank[SA[n - 1]] == n - 1) break;
    }

    return SA;
}

std::vector<int> SuffixLCPAnalyzer::compute_lcp_array(const std::string& text, const std::vector<int>& SA) {
    int n = static_cast<int>(text.size());
    if (n == 0) return {};

    std::vector<int> invSA(n);
    for (int i = 0; i < n; ++i) {
        invSA[SA[i]] = i;
    }

    std::vector<int> LCP(n, 0);
    int h = 0;

    for (int i = 0; i < n; ++i) {
        if (invSA[i] == 0) {
            h = 0;
            continue;
        }

        int j = SA[invSA[i] - 1];

        while (i + h < n && j + h < n && text[i + h] == text[j + h]) {
            h++;
        }

        LCP[invSA[i]] = h;

        if (h > 0) {
            h--;
        }
    }

    return LCP;
}

int SuffixLCPAnalyzer::get_max_suffix_tree_depth(const std::string& text) {
    if (text.empty()) return 0;
    
    std::vector<int> SA = build_suffix_array(text);
    std::vector<int> LCP = compute_lcp_array(text, SA);

    int max_depth = 0;
    for (int val : LCP) {
        if (val > max_depth) {
            max_depth = val;
        }
    }

    return max_depth;
}
