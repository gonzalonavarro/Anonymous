#include "cdc_iblt_reconciliation.h"
#include <chrono>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <unordered_map>

uint64_t CDCIBLTReconciler::make_pair_key(uint64_t left_hash, uint64_t right_hash) {
    uint64_t k = left_hash ^ (right_hash * 0xbf58476d1ce4e5b9ULL + 0x9e3779b97f4a7c15ULL);
    k ^= k >> 30;
    k *= 0x94d049bb133111ebULL;
    k ^= k >> 31;
    return k;
}

std::pair<std::string, CDCReconciliationStats> CDCIBLTReconciler::reconcile(
    const std::string& alice_str,
    const std::string& bob_str,
    size_t estimated_d
) {
    auto start_time = std::chrono::high_resolution_clock::now();
    CDCReconciliationStats stats;

    if (alice_str == bob_str) {
        stats.status = 1;
        stats.decoded_chunks = 0;
        stats.duration_ms = 0.0;
        return {bob_str, stats};
    }

    // --- SAMPLING FIX FOR LARGE PAYLOADS ---
    // Suffix Tree construction on 200MB consumes >10GB RAM.
    // Sample the first 64KB for large files to keep memory footprint < 5MB.
    int max_lcp_depth = 32;
    if (alice_str.size() <= 1024 * 1024) {
        max_lcp_depth = SuffixLCPAnalyzer::get_max_suffix_tree_depth(alice_str);
    } else {
        std::string sample = alice_str.substr(0, 64 * 1024);
        max_lcp_depth = SuffixLCPAnalyzer::get_max_suffix_tree_depth(sample);
    }
    stats.calculated_max_lcp = static_cast<size_t>(max_lcp_depth);

    std::cout << max_lcp_depth;

    size_t cap = std::max<size_t>(16, alice_str.size() / 16);
    size_t min_chunk_s = std::min(cap, std::max<size_t>(16, static_cast<size_t>(max_lcp_depth) + 1));
    stats.configured_min_chunk_s = min_chunk_s;

    std::vector<Chunk> alice_chunks = cdc_chunks(alice_str, min_chunk_s * 2);
    std::vector<Chunk> bob_chunks   = cdc_chunks(bob_str, min_chunk_s * 2);

    stats.alice_chunk_count = alice_chunks.size();
    stats.bob_chunk_count   = bob_chunks.size();

    if (alice_chunks.size() < 2 || bob_chunks.size() < 2) {
        stats.bits_exchanged += alice_str.size() * 8;
        stats.status = 0;
        auto end_time = std::chrono::high_resolution_clock::now();
        stats.duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();
        return {alice_str, stats};
    }

    struct PairMeta {
        size_t index;
        const Chunk* left;
        const Chunk* right;
    };

    std::unordered_map<uint64_t, std::vector<PairMeta>> alice_pair_map;
    for (size_t i = 0; i + 1 < alice_chunks.size(); ++i) {
        uint64_t key = make_pair_key(alice_chunks[i].hash, alice_chunks[i + 1].hash);
        alice_pair_map[key].push_back({i, &alice_chunks[i], &alice_chunks[i + 1]});
    }

    std::unordered_map<uint64_t, std::vector<PairMeta>> bob_pair_map;
    for (size_t j = 0; j + 1 < bob_chunks.size(); ++j) {
        uint64_t key = make_pair_key(bob_chunks[j].hash, bob_chunks[j + 1].hash);
        bob_pair_map[key].push_back({j, &bob_chunks[j], &bob_chunks[j + 1]});
    }

    size_t n = std::max(alice_str.size(), bob_str.size());
    double log_n = std::max(2.0, std::log2(static_cast<double>(n)));

    double mult = 1.0;
    int final_status = 0;
    std::string final_reconstructed = bob_str;

    for (int retry = 0; retry <= 5; ++retry) {
        size_t capacity = std::max<size_t>(16, static_cast<size_t>(8 * estimated_d * mult));
        IBLT tA(capacity);
        IBLT tB(capacity);

        for (const auto& [key, meta_list] : alice_pair_map) {
            for (size_t c = 0; c < meta_list.size(); ++c) tA.insert(key);
        }
        for (const auto& [key, meta_list] : bob_pair_map) {
            for (size_t c = 0; c < meta_list.size(); ++c) tB.insert(key);
        }

        stats.bits_exchanged += tA.size() * (64 + 32);

        IBLT t_delta = tA - tB;
        std::set<uint64_t> diff_keys;
        bool ok = t_delta.listEntries(diff_keys);

        if (ok) {
            stats.decoded_chunks = diff_keys.size();
            std::vector<std::string> reconstructed_chunks(alice_chunks.size());
            std::vector<bool> chunk_filled(alice_chunks.size(), false);

            for (const auto& [key, b_meta_list] : bob_pair_map) {
                if (diff_keys.find(key) == diff_keys.end()) {
                    auto a_it = alice_pair_map.find(key);
                    if (a_it != alice_pair_map.end()) {
                        const PairMeta& b_ref = b_meta_list[0];
                        std::string left_s  = bob_str.substr(b_ref.left->start, b_ref.left->end - b_ref.left->start);
                        std::string right_s = bob_str.substr(b_ref.right->start, b_ref.right->end - b_ref.right->start);

                        for (const auto& a_meta : a_it->second) {
                            size_t idx = a_meta.index;
                            reconstructed_chunks[idx]     = left_s;
                            reconstructed_chunks[idx + 1] = right_s;
                            chunk_filled[idx]     = true;
                            chunk_filled[idx + 1] = true;
                        }
                    }
                }
            }

            for (uint64_t key : diff_keys) {
                auto a_it = alice_pair_map.find(key);
                if (a_it != alice_pair_map.end()) {
                    for (const auto& a_meta : a_it->second) {
                        size_t idx = a_meta.index;
                        const Chunk* left_c  = a_meta.left;
                        const Chunk* right_c = a_meta.right;

                        std::string left_str  = alice_str.substr(left_c->start, left_c->end - left_c->start);
                        std::string right_str = alice_str.substr(right_c->start, right_c->end - right_c->start);

                        reconstructed_chunks[idx]     = left_str;
                        reconstructed_chunks[idx + 1] = right_str;
                        chunk_filled[idx]     = true;
                        chunk_filled[idx + 1] = true;

                        stats.bits_exchanged += (left_str.size() + right_str.size()) * 8 + 64 + 64;
                    }
                }
            }

            bool all_filled = true;
            std::string assembled = "";
            for (size_t i = 0; i < reconstructed_chunks.size(); ++i) {
                if (!chunk_filled[i]) {
                    all_filled = false;
                    break;
                }
                assembled += reconstructed_chunks[i];
            }

            if (all_filled && assembled == alice_str) {
                final_reconstructed = assembled;
                final_status = 1;
                break;
            } else {
                final_status = 2;
            }
        }
        mult *= log_n;
    }

    if (final_status != 1) {
        stats.bits_exchanged += alice_str.size() * 8;
        final_reconstructed = alice_str;
    }

    stats.status = final_status;
    auto end_time = std::chrono::high_resolution_clock::now();
    stats.duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();

    return {final_reconstructed, stats};
}
