#ifndef SUFFIX_LCP_H
#define SUFFIX_LCP_H

#include <string>
#include <vector>
#include <cstddef>

class SuffixLCPAnalyzer {
public:
    static std::vector<int> build_suffix_array(const std::string& text);
    static std::vector<int> compute_lcp_array(const std::string& text, const std::vector<int>& SA);
    static int get_max_suffix_tree_depth(const std::string& text);
};

#endif
