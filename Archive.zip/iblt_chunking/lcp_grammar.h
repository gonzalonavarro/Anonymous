#ifndef LCP_GRAMMAR_H
#define LCP_GRAMMAR_H

#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>

struct ProductionRule {
    uint64_t id;
    std::vector<uint64_t> rhs;
};

struct GrammarLevel {
    std::unordered_map<uint64_t, ProductionRule> rules;
};

class LCPGrammarBuilder {
public:
    static std::pair<std::vector<GrammarLevel>, uint64_t> build_grammar(
        const std::string& str,
        uint32_t shared_seed = 1337
    );

    static std::string reconstruct_from_grammar(
        uint64_t alice_root_id,
        size_t alice_num_levels,
        const std::vector<std::unordered_map<uint64_t, ProductionRule>>& levels
    );
};

#endif 
