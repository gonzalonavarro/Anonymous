#include "reconciliation.h"
#include "cdc_iblt_reconciliation.h"
#include "rsync_util.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <algorithm>

static std::string read_file_to_string(const std::string& filepath) {
    std::ifstream file(filepath, std::ios::binary | std::ios::ate);
    if (!file.is_open()) return "";
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    std::string buffer(size, '\0');
    if (file.read(&buffer[0], size)) {
        return buffer;
    }
    return "";
}

static std::string load_pair_file(const std::string& dir, const std::string& role) {
    std::string extensions[] = {".tar", ".txt", ""};
    for (const auto& ext : extensions) {
        std::string content = read_file_to_string(dir + "/" + role + ext);
        if (!content.empty()) return content;
    }
    return "";
}

int main(int argc, char* argv[]) {
    std::string dataset = (argc > 1) ? argv[1] : "git";
    std::string csv_filename = "exp2_" + dataset + "_concat.csv";

    std::cout << "========================================================\n";
    std::cout << "  EXPERIMENT 2: CONCATENATED MULTI-VERSION [" << dataset << "]\n";
    std::cout << "========================================================\n\n";

    std::ofstream fout(csv_filename);
    if (!fout.is_open()) {
        std::cerr << "Error: Could not create " << csv_filename << "\n";
        return 1;
    }

    fout << "m_versions,n,max_lcp,cdc_status,cdc_decoded_chunks,cdc_bits,cdc_time_ms,lcp_status,lcp_decoded_chunks,lcp_bits,lcp_time_ms,rsync_bits,rsync_time_ms,raw_bits\n";

    std::string alice_concat = "";
    std::string bob_concat   = "";

    const int max_versions = 30;
    int successfully_concatenated = 0;

    for (int v = 0; v < max_versions; ++v) {
        std::string dir = "data/" + dataset + "_pairs/pair_" + std::to_string(v);
        std::string alice_ver = load_pair_file(dir, "alice");
        std::string bob_ver   = load_pair_file(dir, "bob");

        if (alice_ver.empty() || bob_ver.empty()) continue;

        alice_concat += alice_ver.substr(0, std::min<size_t>(alice_ver.size(), 128 * 1024));
        bob_concat   += bob_ver.substr(0, std::min<size_t>(bob_ver.size(), 128 * 1024));

        successfully_concatenated++;
        size_t n = std::max(alice_concat.size(), bob_concat.size());
        size_t raw_bits = n * 8;
        size_t estimated_k = successfully_concatenated * 32;

        auto [cdc_recon, cdc_stats] = CDCIBLTReconciler::reconcile(alice_concat, bob_concat, estimated_k);
        auto [lcp_recon, lcp_stats] = StringReconciler::reconcile(alice_concat, bob_concat, estimated_k);
        RsyncStats rsync_stats      = measure_rsync(alice_concat, bob_concat);

        fout << successfully_concatenated << "," << n << "," << cdc_stats.calculated_max_lcp << ","
             << cdc_stats.status << "," << cdc_stats.decoded_chunks << "," << cdc_stats.bits_exchanged << "," << cdc_stats.duration_ms << ","
             << lcp_stats.status << "," << lcp_stats.decoded_chunks << "," << lcp_stats.bits_exchanged << "," << lcp_stats.duration_ms << ","
             << rsync_stats.bits_exchanged << "," << rsync_stats.duration_ms << ","
             << raw_bits << "\n" << std::flush;

        std::cout << "M=" << std::setw(2) << successfully_concatenated
                  << " | N=" << std::setw(7) << (n / 1024) << " KB"
                  << " | Max LCP: " << std::setw(6) << cdc_stats.calculated_max_lcp
                  << " | CDC Peeled: " << std::setw(3) << cdc_stats.decoded_chunks
                  << " | LCP Peeled: " << std::setw(3) << lcp_stats.decoded_chunks << "\n";
    }

    fout.close();
    std::cout << "\nExp 2 [" << dataset << "] Complete. Output saved to " << csv_filename << "\n";
    return 0;
}
