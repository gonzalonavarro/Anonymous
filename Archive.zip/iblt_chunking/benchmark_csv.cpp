#include "reconciliation.h"
#include "cdc_iblt_reconciliation.h"
#include "rsync_util.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <random>
#include <chrono>
#include <cmath>
#include <algorithm>

static const int NUM_RUNS = 10;

static std::string generate_base_string(size_t n, uint32_t seed = 42) {
    std::string s(n, 'a');
    std::mt19937 rng(seed);
    std::uniform_int_distribution<int> dist('a', 'z');
    for (size_t i = 0; i < n; ++i) {
        s[i] = static_cast<char>(dist(rng));
    }
    return s;
}

static std::string generate_synthetic_pair(const std::string& base, size_t k, uint32_t seed) {
    std::mt19937 rng(seed);
    std::string modified = base;
    std::uniform_int_distribution<int> op_dist(0, 2);
    std::uniform_int_distribution<int> char_dist('a', 'z');

    for (size_t i = 0; i < k; ++i) {
        if (modified.empty()) break;
        std::uniform_int_distribution<size_t> pos_dist(0, modified.size() - 1);
        size_t pos = pos_dist(rng);
        int op = op_dist(rng);
        char c = static_cast<char>(char_dist(rng));

        if (op == 0) {
            modified[pos] = c;
        } else if (op == 1) {
            modified.insert(pos, 1, c);
        } else {
            modified.erase(pos, 1);
        }
    }
    return modified;
}

void run_correctness_tests() {
    std::cout << "========================================================\n";
    std::cout << "  RUNNING PRE-BENCHMARK CORRECTNESS TESTS (CDC & LCP)  \n";
    std::cout << "========================================================\n";

    struct TestCase {
        std::string name;
        std::string alice;
        std::string bob;
        size_t estimated_k;
    };

    std::string text_base = "The quick brown fox jumps over the lazy dog. Content-defined chunking "
                            "and locally consistent parsing handle string reconciliation effectively.";
    
    std::string sub_bob = text_base; sub_bob[12] = 'Z';
    std::string ins_bob = text_base; ins_bob.insert(25, "INSERTED_WORD_");
    std::string del_bob = text_base; del_bob.erase(10, 8);

    std::string rep_alice = "";
    for (int i = 0; i < 50; ++i) rep_alice += "REPETITIVE_PATTERN_SEQUENCE_123_";
    std::string rep_bob = rep_alice; rep_bob[120] = 'X';

    std::string rand_alice = generate_base_string(4096, 777);
    std::string rand_bob   = generate_synthetic_pair(rand_alice, 8, 888);

    std::vector<TestCase> test_cases = {
        {"Exact Match (0 Edits)",          text_base,  text_base,  1},
        {"Single Substitution",           text_base,  sub_bob,    1},
        {"Single Insertion",              text_base,  ins_bob,    2},
        {"Single Deletion",               text_base,  del_bob,    2},
        {"Random Multi-Edits (k=8)",      rand_alice, rand_bob,   8},
        {"Repetitive Pattern (Deep LCP)", rep_alice,  rep_bob,    2}
    };

    int passed = 0;
    int total = static_cast<int>(test_cases.size());

    for (const auto& test : test_cases) {
        auto [cdc_rec, cdc_stats] = CDCIBLTReconciler::reconcile(test.alice, test.bob, test.estimated_k);
        bool cdc_ok = (cdc_rec == test.alice);

        auto [lcp_rec, lcp_stats] = StringReconciler::reconcile(test.alice, test.bob, test.estimated_k);
        bool lcp_ok = (lcp_rec == test.alice);

        std::cout << " Test: " << std::left << std::setw(32) << test.name
                  << " | CDC: " << (cdc_ok ? "[PASS]" : "[FAIL]") << " (Chunks: " << cdc_stats.decoded_chunks << ", Time: " << std::fixed << std::setprecision(2) << cdc_stats.duration_ms << " ms)"
                  << " | LCP: " << (lcp_ok ? "[PASS]" : "[FAIL]") << " (Rules: " << lcp_stats.decoded_chunks << ", Time: " << std::fixed << std::setprecision(2) << lcp_stats.duration_ms << " ms)\n";

        if (cdc_ok && lcp_ok) {
            passed++;
        }
    }

    std::cout << " Correctness Summary: " << passed << "/" << total << " test cases passed.\n";
    if (passed < total) {
        std::cout << " [WARNING] " << (total - passed) << " test(s) relied on fallback or failed. Proceeding with benchmarks...\n";
    } else {
        std::cout << " [INFO] All correctness tests passed successfully.\n";
    }
    std::cout << "========================================================\n\n";
}

void benchmark_fixed_n_varying_k(size_t n, size_t max_k, const std::string& prefix) {
    std::string combined_csv = prefix + "_fix_size.csv";
    std::ofstream fout(combined_csv);
    fout << "n,k,run,cdc_status,cdc_decoded_chunks,cdc_bits,cdc_time_ms,lcp_status,lcp_decoded_chunks,lcp_bits,lcp_time_ms,rsync_bits,rsync_time_ms,raw_bits\n";

    std::cout << "Running CDC vs LCP vs RSYNC Benchmark: Fixed N = " << n << " | Varying k up to " << max_k << "\n";

    for (size_t k = 1; k <= max_k; k *= 2) {
        for (int run = 0; run < NUM_RUNS; ++run) {
            std::string alice = generate_base_string(n, 1000 + run);
            std::string bob   = generate_synthetic_pair(alice, k, 2000 + run);

            auto [cdc_recon, cdc_stats] = CDCIBLTReconciler::reconcile(alice, bob, k);
            auto [lcp_recon, lcp_stats] = StringReconciler::reconcile(alice, bob, k);
            RsyncStats rsync_stats      = measure_rsync(alice, bob);

            size_t raw_bits = n * 8;

            // Save raw uncapped bits so Python script can choose whether to cap
            fout << n << "," << k << "," << run << ","
                 << cdc_stats.status << "," << cdc_stats.decoded_chunks << "," << cdc_stats.bits_exchanged << "," << cdc_stats.duration_ms << ","
                 << lcp_stats.status << "," << lcp_stats.decoded_chunks << "," << lcp_stats.bits_exchanged << "," << lcp_stats.duration_ms << ","
                 << rsync_stats.bits_exchanged << "," << rsync_stats.duration_ms << ","
                 << raw_bits << "\n" << std::flush;

            std::cout << "  N=" << n << ", k=" << std::setw(5) << k << ", run=" << run
                      << " | CDC Bits: " << std::setw(8) << cdc_stats.bits_exchanged
                      << " | LCP Bits: " << std::setw(8) << lcp_stats.bits_exchanged
                      << " | RSYNC Bits: " << std::setw(8) << rsync_stats.bits_exchanged << "\n";
        }
    }
    fout.close();
    std::cout << "Results saved to: " << combined_csv << "\n\n";
}

void benchmark_fixed_k_varying_n(size_t max_n, size_t k, const std::string& prefix) {
    std::string combined_csv = prefix + "_fix_d.csv";
    std::ofstream fout(combined_csv);
    fout << "n,k,run,cdc_status,cdc_decoded_chunks,cdc_bits,cdc_time_ms,lcp_status,lcp_decoded_chunks,lcp_bits,lcp_time_ms,rsync_bits,rsync_time_ms,raw_bits\n";

    std::cout << "Running CDC vs LCP vs RSYNC Benchmark: Fixed k = " << k << " | Varying N up to " << max_n << "\n";

    for (size_t n = 1024; n <= max_n; n *= 2) {
        for (int run = 0; run < NUM_RUNS; ++run) {
            std::string alice = generate_base_string(n, 3000 + run);
            std::string bob   = generate_synthetic_pair(alice, k, 4000 + run);

            auto [cdc_recon, cdc_stats] = CDCIBLTReconciler::reconcile(alice, bob, k);
            auto [lcp_recon, lcp_stats] = StringReconciler::reconcile(alice, bob, k);
            RsyncStats rsync_stats      = measure_rsync(alice, bob);

            size_t raw_bits = n * 8;

            fout << n << "," << k << "," << run << ","
                 << cdc_stats.status << "," << cdc_stats.decoded_chunks << "," << cdc_stats.bits_exchanged << "," << cdc_stats.duration_ms << ","
                 << lcp_stats.status << "," << lcp_stats.decoded_chunks << "," << lcp_stats.bits_exchanged << "," << lcp_stats.duration_ms << ","
                 << rsync_stats.bits_exchanged << "," << rsync_stats.duration_ms << ","
                 << raw_bits << "\n" << std::flush;

            std::cout << "  N=" << std::setw(8) << n << ", k=" << k << ", run=" << run
                      << " | CDC Bits: " << std::setw(8) << cdc_stats.bits_exchanged
                      << " | LCP Bits: " << std::setw(8) << lcp_stats.bits_exchanged
                      << " | RSYNC Bits: " << std::setw(8) << rsync_stats.bits_exchanged << "\n";
        }
    }
    fout.close();
    std::cout << "Results saved to: " << combined_csv << "\n\n";
}

void benchmark_fixed_kn_ratio(double ratio, size_t max_n, const std::string& prefix) {
    std::string combined_csv = prefix + "_fixed_ratio.csv";
    std::ofstream fout(combined_csv);
    fout << "n,k,ratio,run,cdc_status,cdc_decoded_chunks,cdc_bits,cdc_time_ms,"
         << "lcp_status,lcp_decoded_chunks,lcp_bits,lcp_time_ms,"
         << "rsync_bits,rsync_time_ms,raw_bits\n";

    std::cout << "Running Fixed k/N Ratio Benchmark (k/N = " << ratio << ")\n";

    for (size_t n = 2048; n <= max_n; n *= 2) {
        size_t k = std::max<size_t>(1, static_cast<size_t>(n * ratio));
        for (int run = 0; run < NUM_RUNS; ++run) {
            std::string alice = generate_base_string(n, 5000 + run);
            std::string bob   = generate_synthetic_pair(alice, k, 6000 + run);

            auto [cdc_recon, cdc_stats] = CDCIBLTReconciler::reconcile(alice, bob, k);
            auto [lcp_recon, lcp_stats] = StringReconciler::reconcile(alice, bob, k);
            RsyncStats rsync_stats      = measure_rsync(alice, bob);

            size_t raw_bits = n * 8;

            fout << n << "," << k << "," << ratio << "," << run << ","
                 << cdc_stats.status << "," << cdc_stats.decoded_chunks << "," << cdc_stats.bits_exchanged << "," << cdc_stats.duration_ms << ","
                 << lcp_stats.status << "," << lcp_stats.decoded_chunks << "," << lcp_stats.bits_exchanged << "," << lcp_stats.duration_ms << ","
                 << rsync_stats.bits_exchanged << "," << rsync_stats.duration_ms << ","
                 << raw_bits << "\n" << std::flush;

            std::cout << "  N=" << std::setw(8) << n << ", k=" << std::setw(6) << k 
                      << " | CDC Status: " << cdc_stats.status 
                      << " | LCP Status: " << lcp_stats.status 
                      << " | rsync Bits/Raw: " << (double)rsync_stats.bits_exchanged / raw_bits << "\n";
        }
    }
    fout.close();
    std::cout << "Results saved to: " << combined_csv << "\n\n";
}

int main() {
    run_correctness_tests();

    std::cout << "========================================================\n";
    std::cout << "  CDC vs LCP vs RSYNC SYNTHETIC BENCHMARK SUITE        \n";
    std::cout << "========================================================\n\n";

    // 1. Fixed N = 256 KB (262,144 bytes), Varying k up to 4,096 edits
    benchmark_fixed_n_varying_k(262144, 4096, "iblt_benchmark");

    // 2. Fixed k = 64 edits, Varying N up to 1 MB (1,048,576 bytes)
    // benchmark_fixed_k_varying_n(1048576, 64, "iblt_benchmark");

    // 3. Fixed k/N ratio = 0.02 (1 edit every 50 bytes), Varying N up to 1 MB
    // benchmark_fixed_kn_ratio(0.02, 1048576, "iblt_benchmark");

    std::cout << "Benchmarking completed successfully.\n";
    return 0;
}
