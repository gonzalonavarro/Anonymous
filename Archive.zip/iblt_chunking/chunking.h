#ifndef CHUNKING_H
#define CHUNKING_H

#include <cstdint>
#include <vector>
#include <string>
#include <deque>
#include <unordered_map>
#include <unordered_set>

struct Chunk {
    size_t start;
    size_t end;
    uint64_t hash;
};

// Rabin-Karp rolling hash for CDC
class RollingHash {
    uint64_t base = 257;
    uint64_t mod  = (1ULL << 61) - 1;
    uint64_t hash = 0;
    std::deque<uint8_t> window;
    size_t w;

public:
    explicit RollingHash(size_t w_) : w(w_) {}

    void slide(uint8_t c) {
        if (window.size() == w) {
            uint8_t out = window.front();
            window.pop_front();
            hash = (hash + mod - (out * pow_base(w - 1)) % mod) % mod;
        }
        window.push_back(c);
        hash = (hash * base + c) % mod;
    }

    bool ready() const { return window.size() == w; }
    uint64_t value() const { return hash; }

private:
    uint64_t pow_base(size_t exp) const {
        uint64_t result = 1;
        uint64_t b = base;
        while (exp) {
            if (exp & 1) result = (result * b) % mod;
            b = (b * b) % mod;
            exp >>= 1;
        }
        return result;
    }
};

std::vector<Chunk> cdc_chunks(const std::string &X, size_t avg_chunk_size);

std::vector<Chunk> lcp_chunks(const std::string& text, size_t min_chunk_size = 2);

void compare_chunks(const std::vector<Chunk>& alice,
                    const std::vector<Chunk>& bob);

#endif
