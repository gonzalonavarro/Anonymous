#include "reconciliation.h"
#include "cdc_iblt_reconciliation.h"
#include "rsync_util.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <algorithm>

static std::string read_file_to_string(const std::string& filepath) {
    std::ifstream file(filepath, std::ios::binary | std::ios::ate);
    if (!file.is_open()) return "";
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    std::string buffer(size, '\0');
    if (file.read(&buffer[0], size)) {
        return buffer;
    }
    return "";
}

static std::string load_pair_file(const std::string& dir, const std::string& role) {
    std::string extensions[] = {".tar", ".txt", ""};
    for (const auto& ext : extensions) {
        std::string content = read_file_to_string(dir + "/" + role + ext);
        if (!content.empty()) return content;
    }
    return "";
}

int main(int argc, char* argv[]) {
    std::string dataset = (argc > 1) ? argv[1] : "git";
    int group_size = (argc > 2) ? std::stoi(argv[2]) : 5; // Group C consecutive pair files
    std::string csv_filename = "exp1_" + dataset + "_concat" + std::to_string(group_size) + "_pairs.csv";

    std::cout << "========================================================\n";
    std::cout << "  EXPERIMENT 1: CONCATENATED PAIRS [" << dataset << "] (Group Size = " << group_size << ")\n";
    std::cout << "========================================================\n\n";

    std::ofstream fout(csv_filename);
    if (!fout.is_open()) {
        std::cerr << "Error: Could not create " << csv_filename << "\n";
        return 1;
    }

    fout << "pair_group,n,k,max_lcp,cdc_status,cdc_decoded_chunks,cdc_bits,cdc_time_ms,lcp_status,lcp_decoded_chunks,lcp_bits,lcp_time_ms,rsync_bits,rsync_time_ms,raw_bits\n";

    const int total_available_pairs = 500;
    int group_id = 0;

    for (int start_pair = 0; start_pair + group_size <= total_available_pairs; start_pair += group_size) {
        std::string alice_concat = "";
        std::string bob_concat   = "";

        // Aggregate C consecutive pair files into a single benchmark payload
        for (int offset = 0; offset < group_size; ++offset) {
            int pair_id = start_pair + offset;
            std::string dir = "data/" + dataset + "_pairs/pair_" + std::to_string(pair_id);
            alice_concat += load_pair_file(dir, "alice");
            bob_concat   += load_pair_file(dir, "bob");
        }

        if (alice_concat.empty() && bob_concat.empty()) continue;

        size_t n = std::max(alice_concat.size(), bob_concat.size());
        size_t raw_bits = n * 8;
        size_t estimated_k = std::clamp<size_t>(n / 2048, 16, 128);

        auto [cdc_recon, cdc_stats] = CDCIBLTReconciler::reconcile(alice_concat, bob_concat, estimated_k);
        auto [lcp_recon, lcp_stats] = StringReconciler::reconcile(alice_concat, bob_concat, estimated_k);
        RsyncStats rsync_stats      = measure_rsync(alice_concat, bob_concat);

        fout << group_id << "," << n << "," << estimated_k << "," << cdc_stats.calculated_max_lcp << ","
             << cdc_stats.status << "," << cdc_stats.decoded_chunks << "," << cdc_stats.bits_exchanged << "," << cdc_stats.duration_ms << ","
             << lcp_stats.status << "," << lcp_stats.decoded_chunks << "," << lcp_stats.bits_exchanged << "," << lcp_stats.duration_ms << ","
             << rsync_stats.bits_exchanged << "," << rsync_stats.duration_ms << ","
             << raw_bits << "\n" << std::flush;

        std::cout << "Group " << std::setw(3) << group_id
                  << " (Pairs " << start_pair << "-" << (start_pair + group_size - 1) << ")"
                  << " | N: " << std::setw(7) << (n / 1024) << " KB"
                  << " | CDC Peeled: " << std::setw(3) << cdc_stats.decoded_chunks
                  << " | LCP Peeled: " << std::setw(3) << lcp_stats.decoded_chunks << "\n";

        group_id++;
    }

    fout.close();
    std::cout << "\nExp 1 [" << dataset << "] Complete. Output saved to " << csv_filename << "\n";
    return 0;
}
