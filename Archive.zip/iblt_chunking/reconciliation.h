#ifndef RECONCILIATION_H
#define RECONCILIATION_H

#include "iblt.h"
#include "lcp_grammar.h"
#include <string>
#include <vector>
#include <cstddef>

struct ReconciliationStats {
    // 0 = IBLT failed, 1 = Everything succeeded, 2 = IBLT succeeded but string comparison failed
    int status{0};
    size_t decoded_chunks{0}; 
    size_t bits_exchanged{0};
    double duration_ms{0.0};
    size_t levels_processed{0};
};

class StringReconciler {
public:
    static std::pair<std::string, ReconciliationStats> reconcile(
        const std::string& alice_str,
        const std::string& bob_str,
        size_t estimated_k
    );
};

#endif // RECONCILIATION_H
