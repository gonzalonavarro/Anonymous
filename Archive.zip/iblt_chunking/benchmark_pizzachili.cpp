#include "reconciliation.h"
#include "cdc_iblt_reconciliation.h"
#include "rsync_util.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <random>
#include <chrono>
#include <algorithm>
#include <filesystem>

namespace fs = std::filesystem;

static std::string read_large_file(const std::string& base_filepath, size_t max_bytes) {
    std::vector<std::string> candidates = {
        base_filepath,
        base_filepath + ".200MB",
        base_filepath + ".txt",
        base_filepath + ".200MB.txt"
    };

    std::string target_path = "";
    for (const auto& path : candidates) {
        if (fs::exists(path) && fs::file_size(path) > 0) {
            target_path = path;
            break;
        }
    }

    if (target_path.empty()) {
        std::cerr << "Error: Could not find dataset file for " << base_filepath << std::endl;
        return "";
    }

    std::ifstream file(target_path, std::ios::binary);
    if (!file.is_open()) return "";

    std::string buffer(max_bytes, '\0');
    file.read(&buffer[0], max_bytes);
    size_t bytes_read = file.gcount();
    buffer.resize(bytes_read);
    
    std::cout << "Loaded " << (bytes_read / (1024 * 1024)) << " MB from " << target_path << std::endl;
    return buffer;
}

static std::string generate_synthetic_pair(const std::string& base, size_t k, uint32_t seed) {
    std::mt19937 rng(seed);
    std::string modified = base;
    std::uniform_int_distribution<int> op_dist(0, 2);
    std::uniform_int_distribution<int> char_dist('a', 'z');

    for (size_t i = 0; i < k; ++i) {
        if (modified.empty()) break;
        std::uniform_int_distribution<size_t> pos_dist(0, modified.size() - 1);
        size_t pos = pos_dist(rng);
        int op = op_dist(rng);
        char c = static_cast<char>(char_dist(rng));

        if (op == 0) modified[pos] = c;
        else if (op == 1) modified.insert(pos, 1, c);
        else modified.erase(pos, 1);
    }
    return modified;
}

void run_pizzachili_benchmark(const std::string& filepath, const std::string& dataset_label) {
    size_t target_size = 200 * 1024 * 1024; // 200 MB
    std::string alice = read_large_file(filepath, target_size);
    if (alice.empty()) {
        std::cerr << "Skipping [" << dataset_label << "] (File not found)." << std::endl;
        return;
    }

    size_t n = alice.size();
    size_t raw_bits = n * 8;
    std::string out_csv = "pizzachili_" + dataset_label + "_results.csv";
    std::ofstream csv(out_csv);

    csv << "dataset,n,k,trial,cdc_status,cdc_chunks,cdc_bits,cdc_time_ms,"
        << "lcp_status,lcp_rules,lcp_bits,lcp_time_ms,rsync_bits,rsync_time_ms,raw_bits\n";

    std::vector<size_t> k_vals = {1, 2, 4, 8, 16, 32, 64, 128};
    const int num_trials = 10;

    for (size_t k : k_vals) {
        std::cout << "\n=== [" << dataset_label << "] N = " << (n / (1024 * 1024)) << " MB, k = " << k << " (Running " << num_trials << " trials) ===" << std::endl;

        for (int trial = 0; trial < num_trials; ++trial) {
            uint32_t seed = static_cast<uint32_t>(1000 + k * 100 + trial);
            std::string bob = generate_synthetic_pair(alice, k, seed);

            // CDC-IBLT
            auto [cdc_rec, cdc_stats] = CDCIBLTReconciler::reconcile(alice, bob, k);

            // LCP-IBLT
            auto [lcp_rec, lcp_stats] = StringReconciler::reconcile(alice, bob, k);

            // rsync
            RsyncStats rsync_stats = measure_rsync(alice, bob);

            std::cout << "  Trial " << std::setw(2) << (trial + 1) << "/" << num_trials
                      << " | CDC status: " << cdc_stats.status
                      << " | LCP status: " << lcp_stats.status
                      << " | rsync bits: " << rsync_stats.bits_exchanged << std::endl;

            csv << dataset_label << "," << n << "," << k << "," << trial << ","
                << cdc_stats.status << "," << cdc_stats.decoded_chunks << "," << cdc_stats.bits_exchanged << "," << cdc_stats.duration_ms << ","
                << lcp_stats.status << "," << lcp_stats.decoded_chunks << "," << lcp_stats.bits_exchanged << "," << lcp_stats.duration_ms << ","
                << rsync_stats.bits_exchanged << "," << rsync_stats.duration_ms << ","
                << raw_bits << "\n" << std::flush;
        }
    }
    csv.close();
    std::cout << "Results written to " << out_csv << std::endl;
}

int main() {
    std::cout << "========================================================\n";
    std::cout << "  PIZZA&CHILI 200MB BENCHMARK SUITE (10 TRIALS / POINT)  \n";
    std::cout << "========================================================\n\n";

    // run_pizzachili_benchmark("datasets/sources", "sources_non_repetitive");
    run_pizzachili_benchmark("datasets/para", "para_repetitive");

    // run_pizzachili_benchmark("datasets/cere", "cere_repetitive");

    return 0;
}
