#include "reconciliation.h"
#include <iostream>
#include <string>
#include <vector>
#include <random>
#include <cassert>

// Test string generator with controlled edit operations
std::string inject_edits(const std::string& base, size_t num_edits, uint32_t seed = 42) {
    std::mt19937 rng(seed);
    std::string modified = base;
    std::uniform_int_distribution<size_t> pos_dist(0, base.size() - 1);
    std::uniform_int_distribution<int> op_dist(0, 2);
    std::uniform_int_distribution<int> char_dist('a', 'z');

    for (size_t i = 0; i < num_edits; ++i) {
        if (modified.empty()) break;
        size_t pos = pos_dist(rng) % modified.size();
        int op = op_dist(rng);

        if (op == 0) { // Substitution
            modified[pos] = static_cast<char>(char_dist(rng));
        } else if (op == 1) { // Insertion
            modified.insert(pos, 1, static_cast<char>(char_dist(rng)));
        } else { // Deletion
            modified.erase(pos, 1);
        }
    }
    return modified;
}

void run_test_case(const std::string& name, const std::string& alice_str, const std::string& bob_str, size_t k) {
    std::cout << "==================================================\n";
    std::cout << " RUNNING TEST: " << name << "\n";
    std::cout << " String Length (Alice): " << alice_str.size() << " bytes\n";
    std::cout << " String Length (Bob)  : " << bob_str.size() << " bytes\n";
    std::cout << " Estimated Edits (k)  : " << k << "\n";

    auto [reconstructed, stats] = StringReconciler::reconcile(alice_str, bob_str, k);

    std::cout << " Reconciliation Status: " << (stats.success ? "SUCCESS [MATCH]" : "FAILED [MISMATCH]") << "\n";
    std::cout << " Communication Cost   : " << stats.bits_exchanged << " bits (" << (stats.bits_exchanged / 8) << " bytes)\n";
    std::cout << " Processed Levels     : " << stats.levels_processed << "\n";
    std::cout << " Execution Overhead   : " << stats.duration_ms << " ms\n";
    std::cout << "==================================================\n\n";

    assert(stats.success && "Reconstructed string must match Alice's original string exactly.");
}

int main() {
    std::cout << "Starting Local Verification Suite for LCP-IBLT System...\n\n";

    // Test 1: Synthetic English Text Reconciliation
    std::string base_text = "Distributed systems require communication-efficient protocols for reconciling "
                            "character strings across high-latency network channels without retransmitting raw datasets.";
    std::string alice_text = base_text;
    std::string bob_text = inject_edits(base_text, 3, 101); // 3 edits injected
    run_test_case("Synthetic Text (Low Edit Distance)", alice_text, bob_text, 3);

    // Test 2: Biological DNA Sequence Reconciliation
    std::string dna_base;
    dna_base.reserve(10000);
    const char bases[] = {'A', 'C', 'G', 'T'};
    std::mt19937 rng(1337);
    for (size_t i = 0; i < 10000; ++i) {
        dna_base.push_back(bases[rng() % 4]);
    }
    std::string alice_dna = dna_base;
    std::string bob_dna = inject_edits(dna_base, 12, 2022); // 12 edits injected
    run_test_case("DNA Sequence (Genome Reconstruction)", alice_dna, bob_dna, 12);

    // Test 3: Repetitive Sequence (RLE & Grammar Compression)
    std::string rep_alice = "";
    std::string rep_bob = "";
    for (int i = 0; i < 500; ++i) {
        rep_alice += "AAAAAAABBBBBBBCCCCCCC";
        rep_bob   += (i == 250) ? "AAAAAAABBBBBBXCCCCCCC" : "AAAAAAABBBBBBBCCCCCCC";
    }
    run_test_case("Highly Repetitive Run-Length Encoded Text", rep_alice, rep_bob, 2);

    std::cout << "All test cases passed successfully.\n";
    return 0;
}
