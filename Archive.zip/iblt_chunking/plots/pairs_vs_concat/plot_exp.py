import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# CLI process creation overhead floor for rsync
RSYNC_OVERHEAD_MS = 45.0  

plt.rcParams.update({
    "font.size": 10,
    "axes.labelsize": 11,
    "axes.titlesize": 12,
    "legend.fontsize": 8.5,
    "figure.autolayout": True
})

def plot_exp1(csv_file, title_prefix, out_png):
    try:
        df = pd.read_csv(csv_file)
    except Exception:
        return
    if df.empty: return

    # Determine X-axis column and convert to NumPy array
    x_col = 'pair' if 'pair' in df.columns else 'pair_id'
    x_data = df[x_col].to_numpy()

    # Net rsync runtime
    rsync_net_ms = np.maximum(df['rsync_time_ms'].to_numpy() - RSYNC_OVERHEAD_MS, 0.01)

    # Convert bit series to raw KB NumPy arrays and apply fallback caps
    raw_series = df['raw_bits'] if 'raw_bits' in df.columns else df['raw_bytes'] * 8
    raw_kb = (raw_series / 8192.0).to_numpy()

    cdc_kb = np.minimum((df['cdc_bits'] / 8192.0).to_numpy(), raw_kb)
    lcp_kb = np.minimum((df['lcp_bits'] / 8192.0).to_numpy(), raw_kb)
    rsync_kb = np.minimum((df['rsync_bits'] / 8192.0).to_numpy(), raw_kb)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    fig.suptitle(f"Consecutive {title_prefix} Revision Pairs", fontsize=14, fontweight='bold')

    # 1. Bandwidth
    axes[0].plot(x_data, raw_kb, '--', color='gray', label='Raw Payload (KB)')
    axes[0].plot(x_data, cdc_kb, label='CDC-IBLT (KB)', color='tab:blue')
    axes[0].plot(x_data, lcp_kb, label='LCP-IBLT (KB)', color='tab:orange')
    axes[0].plot(x_data, rsync_kb, label='rsync (KB)', color='tab:purple')
    axes[0].set_xlabel('Pair ID'); axes[0].set_ylabel('Data Transferred (KB)')
    axes[0].set_title('Bandwidth Consumption'); axes[0].grid(True, linestyle=':', alpha=0.6)
    axes[0].legend(loc='upper right')

    if 'git' in csv_file.lower():
        axes[0].set_yscale('log')
        axes[0].set_ylabel('Data Transferred (KB, Log Scale)')

    # 2. Runtime
    axes[1].plot(x_data, df['cdc_time_ms'].to_numpy(), label='CDC-IBLT Time (ms)', color='tab:blue')
    axes[1].plot(x_data, df['lcp_time_ms'].to_numpy(), label='LCP-IBLT Time (ms)', color='tab:orange')
    axes[1].plot(x_data, rsync_net_ms, label='rsync Net Time (ms)', color='tab:purple')
    axes[1].set_xlabel('Pair ID'); axes[1].set_ylabel('Execution Time (ms)')
    axes[1].set_title('Reconciliation Speed'); axes[1].grid(True, linestyle=':', alpha=0.6)
    axes[1].legend(loc='upper left')

    # 3. Peeling Complexity
    cdc_chunks_col = 'cdc_decoded_chunks' if 'cdc_decoded_chunks' in df.columns else 'cdc_chunks'
    lcp_rules_col = 'lcp_decoded_chunks' if 'lcp_decoded_chunks' in df.columns else 'lcp_rules'
    
    axes[2].plot(x_data, df[cdc_chunks_col].to_numpy(), label='CDC Decoded Chunks', color='tab:blue', linewidth=1.5)
    axes[2].plot(x_data, df[lcp_rules_col].to_numpy(), label='LCP Decoded Rules', color='tab:orange', linewidth=1.5)
    axes[2].set_xlabel('Pair ID'); axes[2].set_ylabel('Peeled Entries Count')
    axes[2].set_title('IBLT Peeling Complexity'); axes[2].grid(True, linestyle=':', alpha=0.6)
    axes[2].legend(loc='upper right')

    plt.savefig(out_png, dpi=300); plt.close()

def plot_exp2(csv_file, title_prefix, out_png):
    try:
        df = pd.read_csv(csv_file)
    except Exception:
        return
    if df.empty: return

    x_col = 'm_versions' if 'm_versions' in df.columns else 'revisions_m'
    x_data = df[x_col].to_numpy()

    rsync_net_ms = np.maximum(df['rsync_time_ms'].to_numpy() - RSYNC_OVERHEAD_MS, 0.01)

    raw_series = df['raw_bits'] if 'raw_bits' in df.columns else df['n'] * 8
    raw_kb = (raw_series / 8192.0).to_numpy()

    cdc_kb = np.minimum((df['cdc_bits'] / 8192.0).to_numpy(), raw_kb)
    lcp_kb = np.minimum((df['lcp_bits'] / 8192.0).to_numpy(), raw_kb)
    rsync_kb = np.minimum((df['rsync_bits'] / 8192.0).to_numpy(), raw_kb)

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    fig.suptitle(f"Concatenated Multi-Version History Stream ({title_prefix})", fontsize=14, fontweight='bold')

    # 1. Bandwidth
    axes[0].plot(x_data, raw_kb, '--', color='gray', label='Raw Stream (KB)')
    axes[0].plot(x_data, cdc_kb, label='CDC-IBLT (KB)', color='tab:blue')
    axes[0].plot(x_data, lcp_kb, label='LCP-IBLT (KB)', color='tab:orange')
    axes[0].plot(x_data, rsync_kb, label='rsync (KB)', color='tab:purple')
    axes[0].set_xlabel('Concatenated Revisions (M)'); axes[0].set_ylabel('Data Transferred (KB)')
    axes[0].set_title('Bandwidth Consumption'); axes[0].grid(True, linestyle=':', alpha=0.6)
    axes[0].legend(loc='upper left')

    # 2. Runtime
    axes[1].plot(x_data, df['cdc_time_ms'].to_numpy(), label='CDC-IBLT Time (ms)', color='tab:blue')
    axes[1].plot(x_data, df['lcp_time_ms'].to_numpy(), label='LCP-IBLT Time (ms)', color='tab:orange')
    axes[1].plot(x_data, rsync_net_ms, label='rsync Net Time (ms)', color='tab:purple')
    axes[1].set_xlabel('Concatenated Revisions (M)'); axes[1].set_ylabel('Execution Time (ms)')
    axes[1].set_title('Reconciliation Speed vs Stream Length'); axes[1].grid(True, linestyle=':', alpha=0.6)
    axes[1].legend(loc='upper left')

    # 3. Peeling Complexity
    cdc_chunks_col = 'cdc_decoded_chunks' if 'cdc_decoded_chunks' in df.columns else 'cdc_chunks'
    lcp_rules_col = 'lcp_decoded_chunks' if 'lcp_decoded_chunks' in df.columns else 'lcp_rules'

    axes[2].plot(x_data, df[cdc_chunks_col].to_numpy(), label='CDC Decoded Chunks', color='tab:blue', linewidth=1.5)
    axes[2].plot(x_data, df[lcp_rules_col].to_numpy(), label='LCP Decoded Rules', color='tab:orange', linewidth=1.5)
    axes[2].set_xlabel('Concatenated Revisions (M)'); axes[2].set_ylabel('Peeled Entries Count')
    axes[2].set_title('IBLT Peeling Complexity'); axes[2].grid(True, linestyle=':', alpha=0.6)
    axes[2].legend(loc='upper left')

    plt.savefig(out_png, dpi=300); plt.close()

if __name__ == '__main__':
    plot_exp1("exp1_einstein_pairs.csv", "Einstein Revision Pairs", "exp1_einstein_pairs_plots.png")
    plot_exp1("exp1_git_pairs.csv", "Git Commit Revision Pairs", "exp1_git_pairs_plots.png")
    plot_exp2("exp2_einstein_concat.csv", "Einstein Revisions", "exp2_einstein_concat_plots.png")
    plot_exp2("exp2_git_concat.csv", "Git Commits", "exp2_git_concat_plots.png")
    print("Dataset experiment figures generated successfully.")
