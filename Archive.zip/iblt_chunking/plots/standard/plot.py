import csv
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Fixed CLI subprocess setup and IPC overhead floor for system rsync
RSYNC_OVERHEAD_MS = 45.0  

# Publication-quality typography and plot styling
plt.rcParams.update({
    "font.size": 11,
    "axes.labelsize": 12,
    "axes.titlesize": 13,
    "legend.fontsize": 8.5,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "figure.autolayout": True
})

def fmt_coeff(val):
    """Formats floating-point coefficients for LaTeX equation legends."""
    if abs(val) >= 1000 or (0 < abs(val) < 0.01):
        exponent = int(np.floor(np.log10(abs(val))))
        mantissa = val / (10**exponent)
        return rf"{mantissa:.2f} \times 10^{{{exponent}}}"
    return f"{val:.2f}"

def load_csv_rows(csv_path):
    path = Path(csv_path)
    if not path.exists():
        return []
    with open(path, mode='r', newline='') as f:
        return list(csv.DictReader(f))

def aggregate_data(rows, x_key, y_key, status_key=None, cap_at_raw=False):
    grouped = defaultdict(list)
    for row in rows:
        if status_key and status_key in row and int(row[status_key]) != 1:
            continue
        if y_key in row and x_key in row:
            try:
                x = float(row[x_key])
                y = float(row[y_key])
                if cap_at_raw and 'raw_bits' in row:
                    raw = float(row['raw_bits'])
                    y = min(y, raw)
                grouped[x].append(y)
            except ValueError:
                continue

    if not grouped:
        return np.array([]), np.array([]), np.array([])

    x_sorted = sorted(grouped.keys())
    means = np.array([np.mean(grouped[x]) for x in x_sorted])
    stds = np.array([np.std(grouped[x], ddof=1) if len(grouped[x]) > 1 else 0.0 for x in x_sorted])
    return np.array(x_sorted), means, stds

def safe_log_yerr(means, stds):
    """Prevents lower standard deviation error bars from going negative on log scale."""
    lower_err = np.minimum(stds, means * 0.9)
    return [lower_err, stds]

# ----------------------------------------------------------------------
# Curve Fitting Models
# ----------------------------------------------------------------------
def model_power(x, a, b):
    return a * (x**b)

def fit_power(x, y):
    if len(x) < 2: return None, None, None, 0.0
    try:
        popt, _ = curve_fit(model_power, x, y, p0=[y[0], 1.0], bounds=(0, np.inf), maxfev=10000)
        y_pred = model_power(x, *popt)
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        r2 = 1.0 - (ss_res / ss_tot) if ss_tot != 0 else 1.0
        x_smooth = np.logspace(np.log2(x.min()), np.log2(x.max()), num=300, base=2)
        y_smooth = model_power(x_smooth, *popt)
        return popt, x_smooth, y_smooth, r2
    except Exception:
        return None, None, None, 0.0

def fit_log(x, y):
    if len(x) < 2: return None, None, None, 0.0
    try:
        log2_x = np.log2(x)
        popt = np.polyfit(log2_x, y, 1)  # y = popt[0]*log2(x) + popt[1]
        y_pred = popt[0] * log2_x + popt[1]
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        r2 = 1.0 - (ss_res / ss_tot) if ss_tot != 0 else 1.0
        x_smooth = np.logspace(np.log2(x.min()), np.log2(x.max()), num=300, base=2)
        y_smooth = popt[0] * np.log2(x_smooth) + popt[1]
        return popt, x_smooth, y_smooth, r2
    except Exception:
        return None, None, None, 0.0

# ----------------------------------------------------------------------
# Plotting Routines
# ----------------------------------------------------------------------
def plot_fix_size(csv_file):
    rows = load_csv_rows(csv_file)
    if not rows: return

    n_target = int(rows[0]['n']) if 'n' in rows[0] else 262144
    raw_bits = n_target * 8

    k_cdc_b, cdc_b_m, cdc_b_s = aggregate_data(rows, 'k', 'cdc_bits', 'cdc_status', cap_at_raw=True)
    k_lcp_b, lcp_b_m, lcp_b_s = aggregate_data(rows, 'k', 'lcp_bits', 'lcp_status', cap_at_raw=True)
    k_rsync_b, rsync_b_m, rsync_b_s = aggregate_data(rows, 'k', 'rsync_bits', None, cap_at_raw=True)

    k_cdc_t, cdc_t_m, cdc_t_s = aggregate_data(rows, 'k', 'cdc_time_ms', 'cdc_status')
    k_lcp_t, lcp_t_m, lcp_t_s = aggregate_data(rows, 'k', 'lcp_time_ms', 'lcp_status')
    k_rsync_t, rsync_t_m, rsync_t_s = aggregate_data(rows, 'k', 'rsync_time_ms', None)

    # Net rsync algorithmic runtime
    rsync_t_m_net = np.maximum(rsync_t_m - RSYNC_OVERHEAD_MS, 0.01)

    # --- Plot 1: Bandwidth vs k (Log-Log Scale, Capped at Raw) ---
    plt.figure(figsize=(8.5, 5.5))
    if len(k_cdc_b) > 0:
        plt.errorbar(k_cdc_b, cdc_b_m, yerr=safe_log_yerr(cdc_b_m, cdc_b_s), fmt='o', color='steelblue', ecolor='cornflowerblue', capsize=3, label='CDC (Mean ± Std)')
    if len(k_lcp_b) > 0:
        plt.errorbar(k_lcp_b, lcp_b_m, yerr=safe_log_yerr(lcp_b_m, lcp_b_s), fmt='s', color='chocolate', ecolor='sandybrown', capsize=3, label='LCP (Mean ± Std)')
    if len(k_rsync_b) > 0:
        plt.errorbar(k_rsync_b, rsync_b_m, yerr=safe_log_yerr(rsync_b_m, rsync_b_s), fmt='^', color='rebeccapurple', ecolor='mediumpurple', capsize=3, label='rsync (Mean ± Std)')

    plt.axhline(y=raw_bits, color='crimson', linestyle=':', label=f'Raw Baseline ({int(raw_bits):,} bits)')

    if len(k_cdc_b) >= 2:
        m_c = k_cdc_b <= 512
        popt, x_sm, y_sm, r2 = fit_power(k_cdc_b[m_c], cdc_b_m[m_c])
        if popt is not None:
            plt.plot(x_sm, y_sm, '--', color='cornflowerblue', label=rf'CDC Fit: $({fmt_coeff(popt[0])}) k^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    if len(k_lcp_b) >= 2:
        m_l = k_lcp_b <= 512
        popt, x_sm, y_sm, r2 = fit_power(k_lcp_b[m_l], lcp_b_m[m_l])
        if popt is not None:
            plt.plot(x_sm, y_sm, '-.', color='sandybrown', label=rf'LCP Fit: $({fmt_coeff(popt[0])}) k^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    plt.xscale('log', base=2); plt.yscale('log', base=2)
    plt.xlabel('Number of Edits ($k$)'); plt.ylabel('Bits Sent (bits)')
    plt.title(f'Bandwidth vs Edits k (Fixed N = {n_target:,})')
    plt.grid(True, which='both', linestyle='--', alpha=0.5); plt.legend(loc='upper left')
    plt.tight_layout(); plt.savefig("cdc_vs_lcp_vs_rsync_bits_vs_k.png", dpi=300); plt.close()

    # --- Plot 2: Runtime vs k (Log-Log Scale) ---
    plt.figure(figsize=(8.5, 5.5))
    if len(k_cdc_t) > 0:
        plt.errorbar(k_cdc_t, cdc_t_m, yerr=safe_log_yerr(cdc_t_m, cdc_t_s), fmt='o', color='steelblue', ecolor='cornflowerblue', capsize=3, label='CDC (Mean ± Std)')
    if len(k_lcp_t) > 0:
        plt.errorbar(k_lcp_t, lcp_t_m, yerr=safe_log_yerr(lcp_t_m, lcp_t_s), fmt='s', color='chocolate', ecolor='sandybrown', capsize=3, label='LCP (Mean ± Std)')
    if len(k_rsync_t) > 0:
        plt.errorbar(k_rsync_t, rsync_t_m_net, yerr=safe_log_yerr(rsync_t_m_net, rsync_t_s), fmt='^', color='rebeccapurple', ecolor='mediumpurple', capsize=3, label='rsync (Net Algorithmic Time)')

    if len(k_cdc_t) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(k_cdc_t, cdc_t_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, '--', color='cornflowerblue', label=rf'CDC Fit: $({fmt_coeff(popt[0])}) k^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    if len(k_lcp_t) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(k_lcp_t, lcp_t_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, '-.', color='sandybrown', label=rf'LCP Fit: $({fmt_coeff(popt[0])}) k^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    plt.xscale('log', base=2); plt.yscale('log', base=2)
    plt.xlabel('Number of Edits ($k$)'); plt.ylabel('Runtime (ms)')
    plt.title(f'Runtime vs Edits k (Fixed N = {n_target:,})')
    plt.grid(True, which='both', linestyle='--', alpha=0.5); plt.legend(loc='upper left')
    plt.tight_layout(); plt.savefig("cdc_vs_lcp_vs_rsync_runtime_vs_k.png", dpi=300); plt.close()

def plot_fix_d(csv_file):
    rows = load_csv_rows(csv_file)
    if not rows: return

    k_fixed = int(rows[0]['k']) if 'k' in rows[0] else 64

    n_cdc_b, cdc_b_m, cdc_b_s = aggregate_data(rows, 'n', 'cdc_bits', 'cdc_status', cap_at_raw=True)
    n_lcp_b, lcp_b_m, lcp_b_s = aggregate_data(rows, 'n', 'lcp_bits', 'lcp_status', cap_at_raw=True)
    n_rsync_b, rsync_b_m, rsync_b_s = aggregate_data(rows, 'n', 'rsync_bits', None, cap_at_raw=True)

    n_cdc_t, cdc_t_m, cdc_t_s = aggregate_data(rows, 'n', 'cdc_time_ms', 'cdc_status')
    n_lcp_t, lcp_t_m, lcp_t_s = aggregate_data(rows, 'n', 'lcp_time_ms', 'lcp_status')
    n_rsync_t, rsync_t_m, rsync_t_s = aggregate_data(rows, 'n', 'rsync_time_ms', None)

    rsync_t_m_net = np.maximum(rsync_t_m - RSYNC_OVERHEAD_MS, 0.01)

    # --- Plot 3: Bandwidth vs N (Log-Log Scale, Capped at Raw) ---
    plt.figure(figsize=(8.5, 5.5))
    if len(n_cdc_b) > 0:
        plt.errorbar(n_cdc_b, cdc_b_m, yerr=safe_log_yerr(cdc_b_m, cdc_b_s), fmt='o', color='mediumvioletred', ecolor='palevioletred', capsize=3, label='CDC (Mean ± Std)')
    if len(n_lcp_b) > 0:
        plt.errorbar(n_lcp_b, lcp_b_m, yerr=safe_log_yerr(lcp_b_m, lcp_b_s), fmt='s', color='teal', ecolor='cadetblue', capsize=3, label='LCP (Mean ± Std)')
    if len(n_rsync_b) > 0:
        plt.errorbar(n_rsync_b, rsync_b_m, yerr=safe_log_yerr(rsync_b_m, rsync_b_s), fmt='^', color='rebeccapurple', ecolor='mediumpurple', capsize=3, label='rsync (Mean ± Std)')

    n_min = min(n_cdc_b.min() if len(n_cdc_b) else 1024, n_lcp_b.min() if len(n_lcp_b) else 1024)
    n_max = max(n_cdc_b.max() if len(n_cdc_b) else 1048576, n_lcp_b.max() if len(n_lcp_b) else 1048576)
    x_raw = np.logspace(np.log2(n_min), np.log2(n_max), num=100, base=2)
    y_raw = x_raw * 8.0
    plt.plot(x_raw, y_raw, ':', color='crimson', label='Raw Baseline ($8N$ bits)')

    if len(n_cdc_b) >= 2:
        popt, x_sm, y_sm, r2 = fit_log(n_cdc_b, cdc_b_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, '--', color='palevioletred', label=rf'CDC Fit: $({fmt_coeff(popt[0])})\log_2(N) + ({fmt_coeff(popt[1])})$ ($R^2={r2:.3f}$)')

    if len(n_lcp_b) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(n_lcp_b, lcp_b_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, '-.', color='cadetblue', label=rf'LCP Fit: $({fmt_coeff(popt[0])}) N^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    if len(n_rsync_b) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(n_rsync_b, rsync_b_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, ':', color='mediumpurple', linewidth=2, label=rf'rsync Fit: $({fmt_coeff(popt[0])}) N^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    plt.xscale('log', base=2); plt.yscale('log', base=2)
    plt.xlabel('Sequence Length N'); plt.ylabel('Bits Sent (bits)')
    plt.title(f'Bandwidth vs Sequence Length N (Fixed k = {k_fixed})')
    plt.grid(True, which='both', linestyle='--', alpha=0.5); plt.legend(loc='upper left')
    plt.tight_layout(); plt.savefig("cdc_vs_lcp_vs_rsync_bits_vs_n.png", dpi=300); plt.close()

    # --- Plot 4: Runtime vs N (Log-Log Scale) ---
    plt.figure(figsize=(8.5, 5.5))
    if len(n_cdc_t) > 0:
        plt.errorbar(n_cdc_t, cdc_t_m, yerr=safe_log_yerr(cdc_t_m, cdc_t_s), fmt='o', color='mediumvioletred', ecolor='palevioletred', capsize=3, label='CDC (Mean ± Std)')
    if len(n_lcp_t) > 0:
        plt.errorbar(n_lcp_t, lcp_t_m, yerr=safe_log_yerr(lcp_t_m, lcp_t_s), fmt='s', color='teal', ecolor='cadetblue', capsize=3, label='LCP (Mean ± Std)')
    if len(n_rsync_t) > 0:
        plt.errorbar(n_rsync_t, rsync_t_m_net, yerr=safe_log_yerr(rsync_t_m_net, rsync_t_s), fmt='^', color='rebeccapurple', ecolor='mediumpurple', capsize=3, label='rsync (Net Algorithmic Time)')

    if len(n_cdc_t) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(n_cdc_t, cdc_t_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, '--', color='palevioletred', label=rf'CDC Fit: $({fmt_coeff(popt[0])}) N^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    if len(n_lcp_t) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(n_lcp_t, lcp_t_m)
        if popt is not None:
            plt.plot(x_sm, y_sm, '-.', color='cadetblue', label=rf'LCP Fit: $({fmt_coeff(popt[0])}) N^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    if len(n_rsync_t) >= 2:
        popt, x_sm, y_sm, r2 = fit_power(n_rsync_t, rsync_t_m_net)
        if popt is not None:
            plt.plot(x_sm, y_sm, ':', color='mediumpurple', linewidth=2, label=rf'rsync Fit: $({fmt_coeff(popt[0])}) N^{{{popt[1]:.2f}}}$ ($R^2={r2:.3f}$)')

    plt.xscale('log', base=2); plt.yscale('log', base=2)
    plt.xlabel('Sequence Length N'); plt.ylabel('Runtime (ms)')
    plt.title(f'Runtime vs Sequence Length N (Fixed k = {k_fixed})')
    plt.grid(True, which='both', linestyle='--', alpha=0.5); plt.legend(loc='upper left')
    plt.tight_layout(); plt.savefig("cdc_vs_lcp_vs_rsync_runtime_vs_n.png", dpi=300); plt.close()

def plot_fixed_ratio(csv_file):
    rows = load_csv_rows(csv_file)
    if not rows: return

    ratio = float(rows[0]['ratio']) if 'ratio' in rows[0] else 0.02

    # Extract UNCAPPED raw bits transmitted (cap_at_raw=False)
    n_cdc, cdc_b_m, cdc_b_s = aggregate_data(rows, 'n', 'cdc_bits', 'cdc_status', cap_at_raw=False)
    n_lcp, lcp_b_m, lcp_b_s = aggregate_data(rows, 'n', 'lcp_bits', 'lcp_status', cap_at_raw=False)
    n_rsync, rsync_b_m, rsync_b_s = aggregate_data(rows, 'n', 'rsync_bits', None, cap_at_raw=False)

    # Compute expansion ratio multiplier (Bits Sent / Raw Payload Bits)
    cdc_ratio_m = cdc_b_m / (n_cdc * 8.0)
    lcp_ratio_m = lcp_b_m / (n_lcp * 8.0)
    rsync_ratio_m = rsync_b_m / (n_rsync * 8.0)

    plt.figure(figsize=(8.5, 5.5))
    if len(n_cdc) > 0:
        plt.plot(n_cdc, cdc_ratio_m, 'o-', color='mediumvioletred', label='CDC-IBLT')
    if len(n_lcp) > 0:
        plt.plot(n_lcp, lcp_ratio_m, 's-', color='teal', label='LCP-IBLT')
    if len(n_rsync) > 0:
        plt.plot(n_rsync, rsync_ratio_m, '^-', color='rebeccapurple', label='rsync')

    # 1.0 (100% payload) baseline reference
    plt.axhline(y=1.0, color='crimson', linestyle=':', linewidth=2, label='Raw Payload Baseline (1.0x)')

    plt.xscale('log', base=2)
    plt.xlabel('Sequence Length N (bytes)')
    plt.ylabel('Bandwidth Expansion Ratio (Bits Sent / Raw Bits)')
    plt.title(f'Uncapped Protocol Overhead at Edit Ratio k/N = {ratio} (1 edit per 50B)')
    plt.grid(True, which='both', linestyle='--', alpha=0.5)
    plt.legend(loc='upper right')
    plt.tight_layout()
    plt.savefig("cdc_vs_lcp_vs_rsync_fixed_ratio.png", dpi=300)
    plt.close()

if __name__ == '__main__':
    plot_fix_size("iblt_benchmark_fix_size.csv")
    plot_fix_d("iblt_benchmark_fix_d.csv")
    plot_fixed_ratio("iblt_benchmark_fixed_ratio.csv")
    print("\nUpdated synthetic benchmark plots successfully.")
