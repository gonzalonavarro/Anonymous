import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 10.5,
    "axes.labelsize": 11.5,
    "axes.titlesize": 12.5,
    "legend.fontsize": 9.5,
    "figure.autolayout": True
})

def safe_log_yerr(means, stds):
    """Prevents lower error bars from crossing zero on log scales."""
    lower_err = np.minimum(stds, means * 0.9)
    return [lower_err, stds]

def plot_pizzachili_individual(csv_file, title_label, out_prefix):
    try:
        df = pd.read_csv(csv_file)
    except Exception:
        return
    if df.empty: return

    # Units conversion
    df['cdc_mb'] = df['cdc_bits'] / (8 * 1024 * 1024)
    df['lcp_mb'] = df['lcp_bits'] / (8 * 1024 * 1024)
    df['rsync_mb'] = df['rsync_bits'] / (8 * 1024 * 1024)
    
    df['cdc_time_s'] = df['cdc_time_ms'] / 1000.0
    df['lcp_time_s'] = df['lcp_time_ms'] / 1000.0
    df['rsync_time_s'] = df['rsync_time_ms'] / 1000.0

    raw_mb_val = (df['raw_bits'].iloc[0]) / (8 * 1024 * 1024)
    all_k = np.sort(df['k'].unique())

    cdc_valid = df[df['cdc_status'] == 1]
    lcp_valid = df[df['lcp_status'] == 1]

    # Aggregations for CDC
    if not cdc_valid.empty:
        cdc_grp_bw = cdc_valid.groupby('k')['cdc_mb']
        k_cdc = cdc_grp_bw.mean().index.to_numpy()
        m_cdc_bw = cdc_grp_bw.mean().to_numpy()
        s_cdc_bw = cdc_grp_bw.std(ddof=1).fillna(0).to_numpy()

        cdc_grp_t = cdc_valid.groupby('k')['cdc_time_s']
        k_cdc_t = cdc_grp_t.mean().index.to_numpy()
        m_cdc_t = cdc_grp_t.mean().to_numpy()
        s_cdc_t = cdc_grp_t.std(ddof=1).fillna(0).to_numpy()
    else:
        k_cdc = k_cdc_t = np.array([])

    # Aggregations for LCP
    if not lcp_valid.empty:
        lcp_grp_bw = lcp_valid.groupby('k')['lcp_mb']
        k_lcp = lcp_grp_bw.mean().index.to_numpy()
        m_lcp_bw = lcp_grp_bw.mean().to_numpy()
        s_lcp_bw = lcp_grp_bw.std(ddof=1).fillna(0).to_numpy()

        lcp_grp_t = lcp_valid.groupby('k')['lcp_time_s']
        k_lcp_t = lcp_grp_t.mean().index.to_numpy()
        m_lcp_t = lcp_grp_t.mean().to_numpy()
        s_lcp_t = lcp_grp_t.std(ddof=1).fillna(0).to_numpy()
    else:
        k_lcp = k_lcp_t = np.array([])

    # Aggregations for rsync
    rsync_grp_bw = df.groupby('k')['rsync_mb']
    k_rsync = rsync_grp_bw.mean().index.to_numpy()
    m_rsync_bw = rsync_grp_bw.mean().to_numpy()
    s_rsync_bw = rsync_grp_bw.std(ddof=1).fillna(0).to_numpy()

    rsync_grp_t = df.groupby('k')['rsync_time_s']
    k_rsync_t = rsync_grp_t.mean().index.to_numpy()
    m_rsync_t = rsync_grp_t.mean().to_numpy()
    s_rsync_t = rsync_grp_t.std(ddof=1).fillna(0).to_numpy()

    failed_cdc_k = [k for k in all_k if k not in k_cdc]
    failed_lcp_k = [k for k in all_k if k not in k_lcp]

    # =========================================================================
    # INDIVIDUAL PLOT 1: BANDWIDTH CONSUMPTION
    # =========================================================================
    fig, ax_bw = plt.subplots(figsize=(8.5, 5.5))

    if len(k_cdc) > 0:
        ax_bw.errorbar(k_cdc, m_cdc_bw, yerr=safe_log_yerr(m_cdc_bw, s_cdc_bw), fmt='o', linestyle='--',
                       color='steelblue', ecolor='cornflowerblue', capsize=4, label='CDC-IBLT')

    if len(k_lcp) > 0:
        ax_bw.errorbar(k_lcp, m_lcp_bw, yerr=safe_log_yerr(m_lcp_bw, s_lcp_bw), fmt='s', linestyle='-.',
                       color='chocolate', ecolor='sandybrown', capsize=4, label='LCP-IBLT')

    ax_bw.errorbar(k_rsync, m_rsync_bw, yerr=safe_log_yerr(m_rsync_bw, s_rsync_bw), fmt='^', linestyle=':',
                   color='rebeccapurple', ecolor='mediumpurple', capsize=4, label='rsync')

    # Failures
    if len(failed_cdc_k) > 0:
        ax_bw.plot(failed_cdc_k, [raw_mb_val]*len(failed_cdc_k), 'x', color='crimson',
                   markersize=10, markeredgewidth=2, label='CDC Decoding Failure')
    if len(failed_lcp_k) > 0:
        ax_bw.plot(failed_lcp_k, [raw_mb_val]*len(failed_lcp_k), 'x', color='darkred',
                   markersize=10, markeredgewidth=2, label='LCP Decoding Failure')

    ax_bw.axhline(y=raw_mb_val, color='crimson', linestyle=':', label=f'Raw Baseline ({raw_mb_val:.0f} MB)')
    ax_bw.set_xscale('log', base=2)
    ax_bw.set_yscale('log', base=2)
    
    # Clean Axis Labels
    ax_bw.set_xlabel('Number of Edits ($k$)')
    ax_bw.set_ylabel('Data Transferred (MB)')
    ax_bw.set_title(f'Bandwidth Consumption — {title_label}')
    ax_bw.grid(True, which='both', linestyle='--', alpha=0.5)
    ax_bw.legend(loc='upper left')

    plt.savefig(f"{out_prefix}_bandwidth.png", dpi=300)
    plt.close()

    # =========================================================================
    # INDIVIDUAL PLOT 2: RECONCILIATION SPEED (RUNTIME)
    # =========================================================================
    fig, ax_rt = plt.subplots(figsize=(8.5, 5.5))

    if len(k_cdc_t) > 0:
        ax_rt.errorbar(k_cdc_t, m_cdc_t, yerr=s_cdc_t, fmt='o', linestyle='--',
                       color='steelblue', ecolor='cornflowerblue', capsize=4, label='CDC-IBLT')

    if len(k_lcp_t) > 0:
        ax_rt.errorbar(k_lcp_t, m_lcp_t, yerr=s_lcp_t, fmt='s', linestyle='-.',
                       color='chocolate', ecolor='sandybrown', capsize=4, label='LCP-IBLT')

    ax_rt.errorbar(k_rsync_t, m_rsync_t, yerr=s_rsync_t, fmt='^', linestyle=':',
                   color='rebeccapurple', ecolor='mediumpurple', capsize=4, label='rsync')

    ax_rt.set_xscale('log', base=2)
    ax_rt.set_yscale('linear')
    ax_rt.set_ylim(bottom=0)
    
    # Clean Axis Labels
    ax_rt.set_xlabel('Number of Edits ($k$)')
    ax_rt.set_ylabel('Execution Time (s)')
    ax_rt.set_title(f'Reconciliation Speed — {title_label}')
    ax_rt.grid(True, which='both', linestyle='--', alpha=0.5)
    ax_rt.legend(loc='center right')

    plt.savefig(f"{out_prefix}_runtime.png", dpi=300)
    plt.close()

if __name__ == '__main__':
    plot_pizzachili_individual("pizzachili_sources_non_repetitive_results.csv", "Sources (Non-Repetitive)", "pizzachili_sources")
    plot_pizzachili_individual("pizzachili_para_repetitive_results.csv", "Para Genome (Highly Repetitive)", "pizzachili_para")
    plot_pizzachili_individual("pizzachili_cere_repetitive_results.csv", "Cere Genome (Highly Repetitive)", "pizzachili_cere")
    print("Individual Pizza&Chili benchmark plots generated successfully.")
