#include "chunking.h"
#include <iostream>
#include <cmath>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <random>
#include <limits>

static const uint64_t GEAR_TABLE[256] = {
    0x0000000000000000ULL, 0x0013f9f257545464ULL, 0x0027f3e4ae28a8c8ULL, 0x00340a16f97cfca1ULL,
    0x004fe7c95c515190ULL, 0x005c1e3b0b0505f4ULL, 0x0068142df279f958ULL, 0x007beddfa52da23cULL,
    0x009fc892b8a2a320ULL, 0x008c3160ef26f744ULL, 0x00b83b76168a0be8ULL, 0x00abc28441de5f8cULL,
    0x00df2f5be4f3f2b0ULL, 0x00ccd6a9b3a7a6d4ULL, 0x00f8dcbf4ad15a78ULL, 0x00eb254d1d850e1cULL,
    0x013f902575454640ULL, 0x012c69d722111224ULL, 0x011863c1db6dec88ULL, 0x010b9a338c39b8ecULL,
    0x017077ec291417d0ULL, 0x01638e1e7e4043b4ULL, 0x01578408873cbf18ULL, 0x01447dfad068eb7cULL,
    0x01a058b7cd27e560ULL, 0x01b3a1459a73b104ULL, 0x0187ab53630f4da8ULL, 0x019452a1345b19ccULL,
    0x01efbf7e9176b4f0ULL, 0x01fc468cc622e094ULL, 0x01c84c9a3f5e1c38ULL, 0x01dbb568680a485cULL,
    0x027f204af08a8c80ULL, 0x026cd9b8a7deb8e4ULL, 0x0258d3ae5ea22448ULL, 0x024b2a5c09f6702cULL,
    0x0230c783acdbdd10ULL, 0x02233e71fb8f8974ULL, 0x0217346702f375d8ULL, 0x0204cd9555a721bcULL,
    0x02e0e8d848282fa0ULL, 0x02f3112a1f7c7bc4ULL, 0x02c71b3ce6008768ULL, 0x02d4e2ceb154d30cULL,
    0x02af0f1114797e30ULL, 0x02bcf6e3432d2a54ULL, 0x0288fcf5ba51d6f8ULL, 0x029b0507ed0580bcULL,
    0x0340b06f85cfca00ULL, 0x0353499dd29b9e64ULL, 0x0367438b2be762c8ULL, 0x0374ba797cb336acULL,
    0x030f57a6d99e9b90ULL, 0x031cae548ecacbf4ULL, 0x0328a44277b63358ULL, 0x033b5db020e2673cULL,
    0x03df78f23d6d6920ULL, 0x03cc81006a393d44ULL, 0x03f88b169345c1e8ULL, 0x03eb72e4c411978cULL,
    0x03909f3b613c38b0ULL, 0x038366c936686cd4ULL, 0x03b76cdfcf149078ULL, 0x03a4952d9840c61cULL,
    0x04fe4095e1151900ULL, 0x04edb967b6414d64ULL, 0x04d9b3714f3db1c8ULL, 0x04ca4a831869e5acULL,
    0x04b1a75cbd444890ULL, 0x04a25eaee0101cf4ULL, 0x049654b8136ce058ULL, 0x0485ad4a4438b43cULL,
    0x0461880759b7ba20ULL, 0x047271f50ee3ee44ULL, 0x04467be3f79f12e8ULL, 0x04558211a0cb468cULL,
    0x042e6fc205e6ebb0ULL, 0x043d963052b2bfd4ULL, 0x04099c26abce4378ULL, 0x041a65d4fc9a171cULL,
    0x05c1d0b094505f40ULL, 0x05d22942c3040b24ULL, 0x05e623543a78f788ULL, 0x05f5daa66d2ca3ecULL,
    0x058e3779c8010ed0ULL, 0x059dc08b9f555ab4ULL, 0x05a9c49d6629a618ULL, 0x05ba3d6f317df07cULL,
    0x055e18222cf2fc60ULL, 0x054de1d07baea804ULL, 0x0579ebc682da54a8ULL, 0x056a1234d58e00ccULL,
    0x0511ffeb70a3ad50ULL, 0x0502061927f7f934ULL, 0x05360c0fd18b0598ULL, 0x0525f5fd86df51fcULL,
    0x068160df119f9580ULL, 0x0692992d46cb01e4ULL, 0x06a6933bcfb73d48ULL, 0x06b56ac998e3692cULL,
    0x06ce87164dcece10ULL, 0x06dd7ee41a9a9a74ULL, 0x06e974f2e3e666d8ULL, 0x06fa8d00b4b232bcULL,
    0x061ea84da93d36a0ULL, 0x060d51bffe6962c4ULL, 0x06395ba907159e68ULL, 0x062aa25b5041ca0cULL,
    0x06514f84f56c6730ULL, 0x0642b676a2383354ULL, 0x0676bc605b44cff8ULL, 0x066545920c109b9cULL,
    0x07be00fa64da23c0ULL, 0x07adf908338e77a4ULL, 0x0799f31ecaf2bb08ULL, 0x078a0afc9da6ef6cULL,
    0x07f1e733388b7250ULL, 0x07e21ec16fdf2634ULL, 0x07d614d796a3da98ULL, 0x07c5ed25c1f7be0cULL,
    0x0721c868dc7880e0ULL, 0x0732319a8b2cc484ULL, 0x07063b8c72502828ULL, 0x0715c27e25047c4cULL,
    0x076e2fa18029d170ULL, 0x077dd653d77d8514ULL, 0x0749dc452e0179b8ULL, 0x075a25b779552ddcULL,
    0x089f8013c23a3200ULL, 0x088c79e1956e6664ULL, 0x08b873f76c129ac8ULL, 0x08ab8a053b46ceacULL,
    0x08d067da9e6b6390ULL, 0x08c39e28c93f37f4ULL, 0x08f7943e3043cb58ULL, 0x08e46dc867179f3cULL,
    0x080048817a989120ULL, 0x0813b1732dcce544ULL, 0x0827bb65d4b039e8ULL, 0x0834429783e46d8cULL,
    0x084faf4826c9c0b0ULL, 0x085c56ba719d94d4ULL, 0x08685ca088e16878ULL, 0x087ba552dfb53c1cULL,
    0x09a01036b77f7440ULL, 0x09b3e9c4e02b2024ULL, 0x0987e3d21957dc88ULL, 0x09941a204e0388ecULL,
    0x09eff7ffeb2e25d0ULL, 0x09fcce0db27a71b4ULL, 0x09c8041b45068d18ULL, 0x09dbfded1252f97cULL,
    0x093fd8a40fdad760ULL, 0x092c2156588e8304ULL, 0x09182b40a1f27fa8ULL, 0x090bd2b2f6a62bc0ULL,
    0x09703f6d538b86f0ULL, 0x0963c69f04dfd294ULL, 0x0957cc89fda32e38ULL, 0x0944357baaf77a5cULL,
    0x0a20a05932b0be80ULL, 0x0a3359ab65e4eaecULL, 0x0a0753bd9c981648ULL, 0x0a14aa4fcbccee2cULL,
    0x0a6f47906ee1ef10ULL, 0x0a7cbe6239b5bb74ULL, 0x0a48b474c0c947d8ULL, 0x0a5b4d86979d13bcULL,
    0x0abf68cb8a121da0ULL, 0x0acc9139df4649c4ULL, 0x0a989b2f243ab568ULL, 0x0aa662dd736ee10cULL,
    0x0af08f02d6434c30ULL, 0x0ae376f081171854ULL, 0x0ad77ce6786be4f8ULL, 0x0ac485142f3fa09cULL,
    0x0b1f307c47f5f8c0ULL, 0x0b0cc98e10a1ac24ULL, 0x0b38c398e9dd5008ULL, 0x0b2b3a6abf89046cULL,
    0x0b50d7b51ba4a950ULL, 0x0b432e474cf0fd34ULL, 0x0b772451b58c0198ULL, 0x0b64dd03e2d855fcULL,
    0x0b80f8eeff575be0ULL, 0x0b93011ca8030f84ULL, 0x0ba70b0a517ff328ULL, 0x0bb4f2f8062ba74cULL,
    0x0bc01f27a3060a70ULL, 0x0bd3e6d5f4525e14ULL, 0x0be7edc30d2ea2b8ULL, 0x0bf414315a7af6dcULL,
    0x0cc20086232f3100ULL, 0x0cd1f974747b6564ULL, 0x0ce5f3628d0799c8ULL, 0x0cf60a90da53cdacULL,
    0x0c8de74f7f7e6090ULL, 0x0c9e1ebd282a34f4ULL, 0x0ca214ab0156c858ULL, 0x0cb1ed5956029c3cULL,
    0x0c5dc8149b8d9220ULL, 0x0c4e31e6ccf9c644ULL, 0x0c7a3bf035a53ae8ULL, 0x0c69c20262f16e8cULL,
    0x0c122fddc7dc03b0ULL, 0x0c01d62f908857d4ULL, 0x0c35dc3969f4ab78ULL, 0x0c2625cb3ea0bf1cULL,
    0x0dfd90a3566a7740ULL, 0x0dee6951013e2324ULL, 0x0dda6347f842df88ULL, 0x0dc99ab5af16ebecULL,
    0x0db2776a0a3b26d0ULL, 0x0da18e985d6f72b4ULL, 0x0d95848ea4138e18ULL, 0x0d867d7cf347da7cULL,
    0x0d625831ee08d460ULL, 0x0d71a1c3b95c8004ULL, 0x0d45ab0540207ca8ULL, 0x0d5652f7177428ccULL,
    0x0d2dbff8b25985f0ULL, 0x0d3e460ae50dc194ULL, 0x0d0a4c1c1c712d38ULL, 0x0d19b5ee4b25795cULL,
    0x0ebd20cc13a5bd80ULL, 0x0eaed93e44f1e9e4ULL, 0x0e9ad328bd8d1548ULL, 0x0e892ad2ea09412cULL,
    0x0ef2c7054ff4ec10ULL, 0x0ee13ef718a0b874ULL, 0x0ed534e1e1dc44d8ULL, 0x0ec6cd13b68810bcULL,
    0x0e22e85ea8071ea0ULL, 0x0e3111acdf534ac4ULL, 0x0e051bb0062fb668ULL, 0x0e16e242717be20cULL,
    0x0e6d0f97f4564f30ULL, 0x0e7ef665a3021b54ULL, 0x0e4afc735a7ee7f8ULL, 0x0e5905812d2ab3bcULL,
    0x0f82b0e966e0fb20ULL, 0x0f82b0e966e0fb20ULL, 0x0fa5430dc8c853e8ULL, 0x0fb6baff9f9c078cULL,
    0x0fc257203ab1aa10ULL, 0x0fd1ae226de5fe74ULL, 0x0fe5a4c4949902d8ULL, 0x0ff65d36c3cd56bcULL,
    0x0f1d787bd0425800ULL, 0x0f0e818987160c64ULL, 0x0f3a8b9f7e6af0c8ULL, 0x0f29726d293ea4acULL,
    0x0f529fb28c130990ULL, 0x0f416640db475df4ULL, 0x0f750c56223ba158ULL, 0x0f66f5a4756ff53cULL
};

static uint64_t compute_chunk_hash(const std::string& X, size_t start, size_t end) {
    uint64_t hash = 0;
    for (size_t j = start; j < end; ++j) {
        uint8_t byte = static_cast<uint8_t>(X[j]);
        hash = (hash * 257 + byte) % ((1ULL << 61) - 1);
    }
    return hash;
}

std::vector<Chunk> cdc_chunks(const std::string &X, size_t avg_chunk_size) {
    size_t n = X.size();
    if (n == 0) return {};

    size_t min_chunk = std::max<size_t>(4, avg_chunk_size / 4);
    size_t max_chunk = std::max<size_t>(16, avg_chunk_size * 4);

    size_t mask_bits = static_cast<size_t>(std::round(std::log2(std::max<size_t>(2, avg_chunk_size))));
    uint64_t mask = (1ULL << mask_bits) - 1;

    std::vector<Chunk> chunks;
    size_t start = 0;
    uint64_t fp = 0;

    for (size_t i = 0; i < n; ++i) {
        uint8_t byte = static_cast<uint8_t>(X[i]);
        fp = (fp << 1) + GEAR_TABLE[byte];

        size_t current_len = i - start + 1;

        bool natural_boundary = (current_len >= min_chunk && (fp & mask) == 0);
        bool hard_cap = (current_len >= max_chunk);

        if (natural_boundary || hard_cap) {
            size_t cut = i + 1;
            uint64_t hash = compute_chunk_hash(X, start, cut);
            chunks.push_back({start, cut, hash});
            start = cut;
            fp = 0;
        }
    }

    if (start < n) {
        uint64_t hash = compute_chunk_hash(X, start, n);
        chunks.push_back({start, n, hash});
    }

    return chunks;
}

static uint64_t hash_char(char c) {
    uint64_t x = static_cast<unsigned char>(c) + 1;
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

struct RLE_Element {
    char c;
    size_t start_idx;
    size_t end_idx;
};

std::vector<Chunk> lcp_chunks(const std::string& X, size_t min_chunk_size) {
    if (X.empty()) return {};

    std::vector<RLE_Element> rle;
    size_t i = 0;
    while (i < X.size()) {
        char c = X[i];
        size_t start = i;
        while (i < X.size() && X[i] == c) i++;
        rle.push_back({c, start, i});
    }

    if (rle.size() <= 2) {
        return {{0, X.size(), compute_chunk_hash(X, 0, X.size())}};
    }

    std::vector<uint64_t> pi_vals(rle.size());
    for (size_t j = 0; j < rle.size(); ++j) {
        pi_vals[j] = hash_char(rle[j].c);
    }

    pi_vals[0] = std::numeric_limits<uint64_t>::max();
    pi_vals.back() = 0;

    std::vector<size_t> cut_indices;
    cut_indices.push_back(0);

    for (size_t j = 1; j < rle.size() - 1; ++j) {
        if (pi_vals[j - 1] > pi_vals[j] && pi_vals[j] < pi_vals[j + 1]) {
            cut_indices.push_back(rle[j].end_idx);
        }
    }
    cut_indices.push_back(X.size());

    std::vector<Chunk> chunks;
    size_t start_pos = 0;

    for (size_t k = 1; k < cut_indices.size(); ++k) {
        size_t candidate_end = cut_indices[k];
        if (candidate_end - start_pos >= min_chunk_size || k == cut_indices.size() - 1) {
            chunks.push_back({start_pos, candidate_end, compute_chunk_hash(X, start_pos, candidate_end)});
            start_pos = candidate_end;
        }
    }

    return chunks;
}

void compare_chunks(const std::vector<Chunk>& alice, const std::vector<Chunk>& bob) {
    std::unordered_multimap<uint64_t, const Chunk*> alice_map;
    std::unordered_multimap<uint64_t, const Chunk*> bob_map;

    for (const auto& c : alice) alice_map.emplace(c.hash, &c);
    for (const auto& c : bob) bob_map.emplace(c.hash, &c);

    std::unordered_set<uint64_t> matched;
    for (const auto& [hash, a_chunk] : alice_map) {
        auto range = bob_map.equal_range(hash);
        for (auto it = range.first; it != range.second; ++it) {
            matched.insert(hash);
        }
    }
}
