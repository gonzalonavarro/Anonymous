#ifndef IBLT_H
#define IBLT_H

#include <cstdint>
#include <vector>
#include <set>
#include <string>
#include <cstddef>

// Invertible Bloom Lookup Table (IBLT) cell implementation based on Section 3
struct IBLTCell {
    uint64_t keySum{0};   // XOR sum of 64-bit rule keys
    uint32_t keyCheck{0}; // XOR sum of 32-bit MurmurHash3 checksums
    
    bool empty() const {
        return keySum == 0 && keyCheck == 0;
    }
};

class IBLT {
public:
    IBLT() = default;
    IBLT(size_t capacity, double overprovision_factor = 1.5);

    void insert(uint64_t key);
    void erase(uint64_t key);
    
    // Subtracts two IBLTs cell-by-cell (T_Delta = T_A ^ T_B)
    IBLT operator-(const IBLT& other) const;

    // Peels entries from the table to recover set difference keys
    bool listEntries(std::set<uint64_t>& recovered_keys) const;

    size_t size() const { return table.size(); }

private:
    size_t num_hashes{3};
    std::vector<IBLTCell> table;

    uint32_t compute_check(uint64_t key) const;
    bool is_pure(const IBLTCell& cell) const;
    void xor_key(uint64_t key);
};

#endif // IBLT_H
