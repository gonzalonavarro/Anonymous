#ifndef RSYNC_UTIL_H
#define RSYNC_UTIL_H

#include <iostream>
#include <fstream>
#include <chrono>
#include <cstdlib>
#include <string>
#include <cstdio>
#include <algorithm>

struct RsyncStats {
    size_t bits_exchanged = 0;
    double duration_ms = 0.0;
};

static inline RsyncStats measure_rsync(const std::string& alice_str, const std::string& bob_str) {
    std::string alice_file = "/tmp/alice_bench.tmp";
    std::string bob_file   = "/tmp/bob_bench.tmp";
    std::string dest_file  = "/tmp/bob_updated.tmp";

    {
        std::ofstream fa(alice_file, std::ios::binary);
        fa.write(alice_str.data(), alice_str.size());
        std::ofstream fb(bob_file, std::ios::binary);
        fb.write(bob_str.data(), bob_str.size());
    }

    std::string copy_cmd = "cp " + bob_file + " " + dest_file;
    (void)system(copy_cmd.c_str());

    std::string rsync_cmd = "rsync --no-whole-file --block-size=2048 --checksum --stats --timeout=5 " + alice_file + " " + dest_file + " 2>&1";

    auto start_time = std::chrono::high_resolution_clock::now();
    FILE* pipe = popen(rsync_cmd.c_str(), "r");
    if (!pipe) {
        return {alice_str.size() * 8, 0.0};
    }

    char buffer[256];
    size_t bytes_sent = 0;
    size_t bytes_received = 0;

    // 4. Parse stats robustly regardless of leading spaces
    while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
        std::string line(buffer);
        line.erase(std::remove(line.begin(), line.end(), ','), line.end());

        size_t pos_sent = line.find("Total bytes sent:");
        if (pos_sent != std::string::npos) {
            sscanf(line.c_str() + pos_sent, "Total bytes sent: %zu", &bytes_sent);
            continue;
        }

        size_t pos_recv = line.find("Total bytes received:");
        if (pos_recv != std::string::npos) {
            sscanf(line.c_str() + pos_recv, "Total bytes received: %zu", &bytes_received);
            continue;
        }
    }
    pclose(pipe);

    auto end_time = std::chrono::high_resolution_clock::now();
    double duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();

    size_t total_bits = (bytes_sent + bytes_received) * 8;
    return {total_bits, duration_ms};
}

#endif 
