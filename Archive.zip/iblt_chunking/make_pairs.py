import os
import sys

def generate_natural_einstein_pairs(num_pairs=200, block_size=128*1024, stride=16*1024):
    candidate_paths = [
        "data/pizzachili/einstein.en.txt",
        "pizzachili/einstein.en.txt",
        "einstein.en.txt"
    ]
    
    src_file = None
    for p in candidate_paths:
        if os.path.exists(p):
            src_file = p
            break

    if not src_file:
        print("Error: Could not find 'einstein.en.txt'!")
        sys.exit(1)

    print(f"Reading natural revision corpus from: {src_file}")
    with open(src_file, "r", encoding="utf-8", errors="ignore") as f:
        full_text = f.read()

    out_base = "data/einstein_pairs"
    os.makedirs(out_base, exist_ok=True)

    print(f"Extracting {num_pairs} natural revision pairs (block_size={block_size // 1024}KB, stride={stride // 1024}KB)...")

    total_len = len(full_text)
    
    for i in range(num_pairs):
        # Calculate natural sliding revision offsets across the corpus
        alice_start = (i * stride) % (total_len - block_size - stride)
        bob_start   = alice_start + stride  # Bob is offset by the natural revision stride

        alice_text = full_text[alice_start : alice_start + block_size]
        bob_text   = full_text[bob_start   : bob_start   + block_size]

        pair_dir = os.path.join(out_base, f"pair_{i}")
        os.makedirs(pair_dir, exist_ok=True)

        with open(os.path.join(pair_dir, "alice.txt"), "w", encoding="utf-8") as fa:
            fa.write(alice_text)

        with open(os.path.join(pair_dir, "bob.txt"), "w", encoding="utf-8") as fb:
            fb.write(bob_text)

        if (i + 1) % 25 == 0 or i == num_pairs - 1:
            print(f"  Extracted pair_{i} (Alice offset: {alice_start}, Bob offset: {bob_start})")

    print(f"\nSuccessfully created {num_pairs} natural revision pairs in '{out_base}/'.")

if __name__ == "__main__":
    generate_natural_einstein_pairs()
