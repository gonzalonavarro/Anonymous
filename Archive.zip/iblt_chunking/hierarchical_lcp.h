#ifndef HIERARCHICAL_LCP_H
#define HIERARCHICAL_LCP_H

#include <vector>
#include <string>
#include <cstdint>
#include <unordered_map>
#include <limits>
#include <iostream>

struct GrammarRule {
    uint64_t lhs;
    std::vector<uint64_t> rhs;
    std::string leaf_content; 
};

struct GrammarTree {
    uint64_t root_id;
    std::unordered_map<uint64_t, GrammarRule> rules;
};

inline uint64_t hash_symbol(uint64_t sym, uint64_t level_seed) {
    uint64_t x = sym + level_seed + 1; 
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

inline uint64_t hash_sequence(const std::vector<uint64_t>& seq) {
    uint64_t h = 0;
    for (uint64_t val : seq) {
        h = h * 6364136223846793005ULL + val + 1442695040888963407ULL;
    }
    return h ^ (h >> 31);
}

struct RLE_Block {
    uint64_t symbol;
    size_t start_idx;
    size_t end_idx;
};

inline GrammarTree build_hierarchical_lcp(const std::string& X) {
    GrammarTree tree;
    if (X.empty()) {
        tree.root_id = 0;
        tree.rules[0] = {0, {}, ""};
        return tree;
    }

    std::vector<uint64_t> current_seq;
    current_seq.reserve(X.size());
    for (char c : X) {
        current_seq.push_back(static_cast<unsigned char>(c));
    }

    bool is_base_level = true;
    uint64_t final_root = 0;
    uint64_t level = 0;

    while (true) {
        level++;
        uint64_t level_seed = 0x9e3779b97f4a7c15ULL * level;

        std::vector<RLE_Block> rle;
        size_t i = 0;
        while (i < current_seq.size()) {
            uint64_t sym = current_seq[i];
            size_t start = i;
            while (i < current_seq.size() && current_seq[i] == sym) i++;
            rle.push_back({sym, start, i});
        }

        if (rle.size() <= 2) {
            uint64_t lhs = hash_sequence(current_seq);
            std::string leaf_data = is_base_level ? X : "";
            tree.rules[lhs] = {lhs, current_seq, leaf_data};
            final_root = lhs;
            break; 
        }

        std::vector<uint64_t> pi_vals(rle.size());
        for (size_t j = 0; j < rle.size(); ++j) {
            pi_vals[j] = hash_symbol(rle[j].symbol, level_seed);
        }

        pi_vals[0] = std::numeric_limits<uint64_t>::max();
        pi_vals.back() = 0;

        std::vector<uint64_t> next_seq;
        size_t start_pos = 0;

        for (size_t j = 1; j < rle.size() - 1; ++j) {
            if (pi_vals[j - 1] > pi_vals[j] && pi_vals[j] < pi_vals[j + 1]) {
                size_t cut = rle[j].end_idx;
                
                std::vector<uint64_t> rhs(current_seq.begin() + start_pos, current_seq.begin() + cut);
                uint64_t lhs = hash_sequence(rhs);
                
                std::string leaf_data = is_base_level ? X.substr(start_pos, cut - start_pos) : "";

                tree.rules[lhs] = {lhs, rhs, leaf_data};
                next_seq.push_back(lhs);
                start_pos = cut;
            }
        }

        std::vector<uint64_t> rhs(current_seq.begin() + start_pos, current_seq.end());
        uint64_t lhs = hash_sequence(rhs);
        std::string leaf_data = is_base_level ? X.substr(start_pos, current_seq.size() - start_pos) : "";

        tree.rules[lhs] = {lhs, rhs, leaf_data};
        next_seq.push_back(lhs);

        current_seq = std::move(next_seq);
        is_base_level = false;
        
        if (current_seq.size() == 1) {
            final_root = current_seq[0];
            break;
        }
    }

    tree.root_id = final_root;
    return tree;
}

inline std::string recursively_reconstruct(
    uint64_t node_id, 
    const std::unordered_map<uint64_t, GrammarRule>& merged_dict
) {
    auto it = merged_dict.find(node_id);
    if (it == merged_dict.end()) {
        return "";
    }

    const GrammarRule& rule = it->second;
    if (!rule.leaf_content.empty()) {
        return rule.leaf_content;
    }

    std::string result;
    for (uint64_t child_id : rule.rhs) {
        result += recursively_reconstruct(child_id, merged_dict);
    }
    return result;
}

#endif
