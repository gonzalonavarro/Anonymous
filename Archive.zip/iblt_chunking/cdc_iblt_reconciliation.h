#ifndef CDC_IBLT_RECONCILIATION_H
#define CDC_IBLT_RECONCILIATION_H

#include "iblt.h"
#include "chunking.h"
#include "suffix_lcp.h"
#include <string>
#include <vector>
#include <set>
#include <unordered_map>

struct CDCReconciliationStats {
    // 0 = IBLT failed, 1 = Everything succeeded, 2 = IBLT succeeded but string comparison failed
    int status{0};
    size_t decoded_chunks{0};
    size_t calculated_max_lcp{0};
    size_t configured_min_chunk_s{0};
    size_t alice_chunk_count{0};
    size_t bob_chunk_count{0};
    size_t bits_exchanged{0};
    double duration_ms{0.0};
};

class CDCIBLTReconciler {
public:
    static std::pair<std::string, CDCReconciliationStats> reconcile(
        const std::string& alice_str,
        const std::string& bob_str,
        size_t estimated_d
    );

private:
    static uint64_t make_pair_key(uint64_t left_hash, uint64_t right_hash);
};

#endif
