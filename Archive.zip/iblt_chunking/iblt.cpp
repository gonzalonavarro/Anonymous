#include "iblt.h"
#include <cmath>
#include <algorithm>
#include <queue>
#include <iostream>

// 32-bit MurmurHash3 variant for index generation and purity checking
static uint32_t murmur3_32(const uint8_t* key, size_t len, uint32_t seed) {
    uint32_t h1 = seed;
    constexpr uint32_t c1 = 0xcc9e2d51;
    constexpr uint32_t c2 = 0x1b873593;

    size_t nblocks = len / 4;
    const uint32_t* blocks = reinterpret_cast<const uint32_t*>(key);

    for (size_t i = 0; i < nblocks; ++i) {
        uint32_t k1 = blocks[i];
        k1 *= c1;
        k1 = (k1 << 15) | (k1 >> 17);
        k1 *= c2;

        h1 ^= k1;
        h1 = (h1 << 13) | (h1 >> 19);
        h1 = h1 * 5 + 0xe6546b64;
    }

    const uint8_t* tail = key + nblocks * 4;
    uint32_t k1 = 0;
    switch (len & 3) {
        case 3: k1 ^= tail[2] << 16; [[fallthrough]];
        case 2: k1 ^= tail[1] << 8;  [[fallthrough]];
        case 1: k1 ^= tail[0];
                k1 *= c1;
                k1 = (k1 << 15) | (k1 >> 17);
                k1 *= c2;
                h1 ^= k1;
    }

    h1 ^= static_cast<uint32_t>(len);
    h1 ^= h1 >> 16;
    h1 *= 0x85ebca6b;
    h1 ^= h1 >> 13;
    h1 *= 0xc2b2ae35;
    h1 ^= h1 >> 16;

    return h1;
}

IBLT::IBLT(size_t capacity, double overprovision_factor) {
    size_t cells = static_cast<size_t>(std::ceil(capacity * overprovision_factor));
    cells = std::max<size_t>(16, cells);
    table.resize(cells);
    num_hashes = 3; // Standard 3 hash functions for O(k) peeling

uint32_t IBLT::compute_check(uint64_t key) const {
    return murmur3_32(reinterpret_cast<const uint8_t*>(&key), sizeof(key), 11);
}

bool IBLT::is_pure(const IBLTCell& cell) const {
    if (cell.empty()) return false;
    return compute_check(cell.keySum) == cell.keyCheck;
}

void IBLT::xor_key(uint64_t key) {
    uint32_t check = compute_check(key);
    for (size_t i = 0; i < num_hashes; ++i) {
        size_t idx = murmur3_32(reinterpret_cast<const uint8_t*>(&key), sizeof(key), static_cast<uint32_t>(i)) % table.size();
        table[idx].keySum ^= key;
        table[idx].keyCheck ^= check;
    }
}

void IBLT::insert(uint64_t key) {
    xor_key(key);
}

void IBLT::erase(uint64_t key) {
    xor_key(key);
}

IBLT IBLT::operator-(const IBLT& other) const {
    IBLT diff = *this;
    for (size_t i = 0; i < table.size(); ++i) {
        diff.table[i].keySum ^= other.table[i].keySum;
        diff.table[i].keyCheck ^= other.table[i].keyCheck;
    }
    return diff;
}

bool IBLT::listEntries(std::set<uint64_t>& recovered_keys) const {
    IBLT peeled = *this;
    std::queue<size_t> pure_queue;

    for (size_t i = 0; i < peeled.table.size(); ++i) {
        if (peeled.is_pure(peeled.table[i])) {
            pure_queue.push(i);
        }
    }

    while (!pure_queue.empty()) {
        size_t idx = pure_queue.front();
        pure_queue.pop();

        const auto& cell = peeled.table[idx];
        if (!peeled.is_pure(cell)) continue;

        uint64_t key = cell.keySum;
        recovered_keys.insert(key);

        peeled.erase(key);

        for (size_t i = 0; i < peeled.table.size(); ++i) {
            if (peeled.is_pure(peeled.table[i])) {
                pure_queue.push(i);
            }
        }
    }

    for (const auto& cell : peeled.table) {
        if (!cell.empty()) return false;
    }

    return true;
}
