#include "lcp_grammar.h"
#include <algorithm>
#include <limits>

// Stateless 2-universal hash function for pi
static uint64_t hash_pi(uint64_t sym, uint32_t level_seed) {
    uint64_t x = sym ^ (static_cast<uint64_t>(level_seed) * 0x9e3779b97f4a7c15ULL);
    x ^= x >> 30;
    x *= 0xbf58476d1ce4e5b9ULL;
    x ^= x >> 27;
    x *= 0x94d049bb133111ebULL;
    x ^= x >> 31;
    return x;
}

static uint64_t hash_rule(const std::vector<uint64_t>& rhs) {
    uint64_t h = 0xbf58476d1ce4e5b9ULL;
    for (uint64_t val : rhs) {
        h ^= val + 0x9e3779b97f4a7c15ULL + (h << 6) + (h >> 2);
    }
    return h;
}

std::pair<std::vector<GrammarLevel>, uint64_t> LCPGrammarBuilder::build_grammar(
    const std::string& str,
    uint32_t shared_seed
) {
    if (str.empty()) return {{}, 0};

    std::vector<GrammarLevel> levels;
    
    // Step 1: Initial RLE Encoding as specified in Section 4(1)
    std::vector<uint64_t> current_symbols;
    current_symbols.reserve(str.size());

    for (size_t i = 0; i < str.size();) {
        size_t j = i;
        while (j < str.size() && str[j] == str[i]) {
            j++;
        }
        size_t run_len = j - i;
        uint64_t base_char = static_cast<unsigned char>(str[i]);
        if (run_len > 1) {
            // Encode run <a, k> into a unique symbol key
            uint64_t run_sym = base_char | (static_cast<uint64_t>(run_len) << 32);
            current_symbols.push_back(run_sym);
        } else {
            current_symbols.push_back(base_char);
        }
        i = j;
    }

    uint32_t level_seed = shared_seed;

    // Step 2: Multi-level LCP Chunking
    while (current_symbols.size() > 1) {
        GrammarLevel level;
        std::vector<uint64_t> next_symbols;

        std::vector<size_t> cuts;
        cuts.push_back(0);

        for (size_t i = 1; i + 1 < current_symbols.size(); ++i) {
            // Map run <a, k> to pi(a)
            uint64_t sym_prev = current_symbols[i - 1] & 0xFFFFFFFFULL;
            uint64_t sym_curr = current_symbols[i]     & 0xFFFFFFFFULL;
            uint64_t sym_next = current_symbols[i + 1] & 0xFFFFFFFFULL;

            uint64_t prev_pi = (i == 1) ? std::numeric_limits<uint64_t>::max() : hash_pi(sym_prev, level_seed);
            uint64_t curr_pi = hash_pi(sym_curr, level_seed);
            uint64_t next_pi = (i + 2 == current_symbols.size()) ? 0ULL : hash_pi(sym_next, level_seed);

            if (prev_pi > curr_pi && curr_pi < next_pi) {
                cuts.push_back(i);
            }
        }
        cuts.push_back(current_symbols.size());

        for (size_t c = 0; c + 1 < cuts.size(); ++c) {
            size_t start = cuts[c];
            size_t end   = cuts[c + 1];

            std::vector<uint64_t> rhs(current_symbols.begin() + start, current_symbols.begin() + end);
            uint64_t rule_id = hash_rule(rhs);

            level.rules[rule_id] = ProductionRule{rule_id, rhs};
            next_symbols.push_back(rule_id);
        }

        levels.push_back(level);
        if (next_symbols.size() == current_symbols.size()) break;
        current_symbols = next_symbols;
        level_seed++;
    }

    uint64_t root_id = current_symbols.empty() ? 0 : current_symbols[0];
    return {levels, root_id};
}

std::string LCPGrammarBuilder::reconstruct_from_grammar(
    uint64_t alice_root_id,
    size_t alice_num_levels,
    const std::vector<std::unordered_map<uint64_t, ProductionRule>>& levels
) {
    if (levels.empty() || alice_num_levels == 0) return "";

    std::vector<uint64_t> current = {alice_root_id};

    // Expand strictly from Alice's top level r_A - 1 down to 0
    for (int l = static_cast<int>(alice_num_levels) - 1; l >= 0; --l) {
        std::vector<uint64_t> next;
        for (uint64_t sym : current) {
            if (l < static_cast<int>(levels.size())) {
                auto it = levels[l].find(sym);
                if (it != levels[l].end()) {
                    for (uint64_t child : it->second.rhs) {
                        next.push_back(child);
                    }
                    continue;
                }
            }
            next.push_back(sym);
        }
        current = next;
    }

    // Decode run-length encoded characters back to raw string
    std::string result = "";
    for (uint64_t sym : current) {
        uint64_t base_char = sym & 0xFFFFFFFFULL;
        uint64_t run_len  = sym >> 32;
        if (run_len > 0) {
            result.append(run_len, static_cast<char>(base_char));
        } else {
            result.push_back(static_cast<char>(base_char));
        }
    }
    return result;
}
