#include "reconciliation.h"
#include "hierarchical_lcp.h"
#include "chunking.h"
#include <chrono>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <unordered_map>
#include <set>
#include <vector>

std::pair<std::string, ReconciliationStats> StringReconciler::reconcile(
    const std::string& alice_str,
    const std::string& bob_str,
    size_t estimated_k
) {
    auto start_time = std::chrono::high_resolution_clock::now();
    ReconciliationStats stats;

    if (alice_str == bob_str) {
        stats.status = 1;
        stats.decoded_chunks = 0;
        stats.duration_ms = 0.0;
        return {bob_str, stats};
    }

    size_t n = std::max(alice_str.size(), bob_str.size());

    // ------------------------------------------------------------------
    // Block-Level Hierarchical LCP Grammar Tree
    // ------------------------------------------------------------------
    if (n > 1024 * 1024) {
        size_t min_chunk = std::max<size_t>(128, std::min<size_t>(2048, n / 100000));
        std::vector<Chunk> alice_chunks = lcp_chunks(alice_str, min_chunk);
        std::vector<Chunk> bob_chunks   = lcp_chunks(bob_str, min_chunk);

        if (alice_chunks.empty() || bob_chunks.empty()) {
            stats.bits_exchanged += alice_str.size() * 8;
            stats.status = 0;
            auto end_time = std::chrono::high_resolution_clock::now();
            stats.duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();
            return {alice_str, stats};
        }

        std::unordered_map<uint64_t, std::vector<size_t>> alice_hash_map;
        for (size_t i = 0; i < alice_chunks.size(); ++i) {
            alice_hash_map[alice_chunks[i].hash].push_back(i);
        }

        std::unordered_map<uint64_t, std::vector<size_t>> bob_hash_map;
        for (size_t j = 0; j < bob_chunks.size(); ++j) {
            bob_hash_map[bob_chunks[j].hash].push_back(j);
        }

        std::unordered_map<uint64_t, uint64_t> alice_rules, bob_rules;
        for (size_t i = 0; i + 1 < alice_chunks.size(); ++i) {
            uint64_t parent_rule = alice_chunks[i].hash ^ (alice_chunks[i+1].hash * 0xbf58476d1ce4e5b9ULL);
            alice_rules[parent_rule] = alice_chunks[i].hash;
        }
        for (size_t j = 0; j + 1 < bob_chunks.size(); ++j) {
            uint64_t parent_rule = bob_chunks[j].hash ^ (bob_chunks[j+1].hash * 0xbf58476d1ce4e5b9ULL);
            bob_rules[parent_rule] = bob_chunks[j].hash;
        }

        double log_n = std::max(2.0, std::log2(static_cast<double>(n)));
        double mult = 1.0;
        int final_status = 0;
        std::string final_reconstructed = bob_str;

        for (int retry = 0; retry <= 3; ++retry) {
            size_t capacity = std::max<size_t>(32, static_cast<size_t>(16 * estimated_k * mult));
            IBLT t_alice(capacity);
            IBLT t_bob(capacity);

            for (const auto& [rule_id, child_hash] : alice_rules) t_alice.insert(rule_id);
            for (const auto& [rule_id, child_hash] : bob_rules) t_bob.insert(rule_id);

            stats.bits_exchanged += t_alice.size() * (64 + 32);

            IBLT t_delta = t_alice - t_bob;
            std::set<uint64_t> peeled_rules;
            bool decode_ok = t_delta.listEntries(peeled_rules);

            if (decode_ok) {
                stats.decoded_chunks = peeled_rules.size();
                std::vector<std::string> reconstructed_chunks(alice_chunks.size());
                std::vector<bool> chunk_filled(alice_chunks.size(), false);

                for (const auto& [hash, b_indices] : bob_hash_map) {
                    auto a_it = alice_hash_map.find(hash);
                    if (a_it != alice_hash_map.end()) {
                        size_t b_idx = b_indices[0];
                        std::string content = bob_str.substr(bob_chunks[b_idx].start, bob_chunks[b_idx].end - bob_chunks[b_idx].start);
                        for (size_t a_idx : a_it->second) {
                            reconstructed_chunks[a_idx] = content;
                            chunk_filled[a_idx] = true;
                        }
                    }
                }

                for (uint64_t rule_id : peeled_rules) {
                    auto a_rule_it = alice_rules.find(rule_id);
                    if (a_rule_it != alice_rules.end()) {
                        uint64_t child_hash = a_rule_it->second;
                        auto a_it = alice_hash_map.find(child_hash);
                        if (a_it != alice_hash_map.end()) {
                            for (size_t a_idx : a_it->second) {
                                const Chunk& c = alice_chunks[a_idx];
                                std::string content = alice_str.substr(c.start, c.end - c.start);
                                reconstructed_chunks[a_idx] = content;
                                chunk_filled[a_idx] = true;
                                stats.bits_exchanged += content.size() * 8 + 64;
                            }
                        }
                    }
                }

                bool all_filled = true;
                std::string assembled = "";
                for (size_t i = 0; i < reconstructed_chunks.size(); ++i) {
                    if (!chunk_filled[i]) {
                        all_filled = false;
                        break;
                    }
                    assembled += reconstructed_chunks[i];
                }

                if (all_filled && assembled == alice_str) {
                    final_reconstructed = assembled;
                    final_status = 1;
                    break;
                } else {
                    final_status = 2;
                }
            }
            mult *= log_n;
        }

        if (final_status != 1) {
            stats.bits_exchanged += alice_str.size() * 8;
            final_reconstructed = alice_str;
        }

        stats.status = final_status;
        auto end_time = std::chrono::high_resolution_clock::now();
        stats.duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();

        return {final_reconstructed, stats};
    }

    GrammarTree tree_alice = build_hierarchical_lcp(alice_str);
    GrammarTree tree_bob   = build_hierarchical_lcp(bob_str);

    stats.bits_exchanged += 64;
    double log_n = std::max(2.0, std::log2(static_cast<double>(n)));

    double mult = 1.0;
    int final_status = 0;
    std::string final_reconstructed = bob_str;

    for (int retry = 0; retry <= 3; ++retry) {
        size_t capacity = std::max<size_t>(32, static_cast<size_t>(16 * estimated_k * mult));

        IBLT t_alice(capacity);
        IBLT t_bob(capacity);

        for (const auto& [rule_id, rule] : tree_alice.rules) t_alice.insert(rule_id);
        for (const auto& [rule_id, rule] : tree_bob.rules) t_bob.insert(rule_id);

        stats.bits_exchanged += t_alice.size() * (64 + 32);

        IBLT t_delta = t_alice - t_bob;
        std::set<uint64_t> peeled_rule_ids;
        bool decode_ok = t_delta.listEntries(peeled_rule_ids);

        if (decode_ok) {
            stats.decoded_chunks = peeled_rule_ids.size();
            std::unordered_map<uint64_t, GrammarRule> merged_rules = tree_bob.rules;

            for (uint64_t rule_id : peeled_rule_ids) {
                auto it = tree_alice.rules.find(rule_id);
                if (it != tree_alice.rules.end()) {
                    merged_rules[rule_id] = it->second;
                    size_t rule_bits = 64 + (it->second.rhs.size() * 64) + (it->second.leaf_content.size() * 8);
                    stats.bits_exchanged += rule_bits;
                }
            }

            std::string reconstructed = recursively_reconstruct(tree_alice.root_id, merged_rules);
            if (reconstructed == alice_str) {
                final_reconstructed = reconstructed;
                final_status = 1;
                break;
            } else {
                final_status = 2;
            }
        }
        mult *= log_n;
    }

    if (final_status != 1) {
        stats.bits_exchanged += alice_str.size() * 8;
        final_reconstructed = alice_str;
    }

    stats.status = final_status;
    auto end_time = std::chrono::high_resolution_clock::now();
    stats.duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();

    return {final_reconstructed, stats};
}


// std::pair<std::string, ReconciliationStats> StringReconciler::reconcile(
//     const std::string& alice_str,
//     const std::string& bob_str,
//     size_t estimated_k
// ) {
//     // 1. Start timer at the very top to include Grammar Tree construction
//     auto start_time = std::chrono::high_resolution_clock::now();
//     ReconciliationStats stats;

//     if (alice_str == bob_str) {
//         stats.status = 1;
//         stats.decoded_chunks = 0;
//         stats.duration_ms = 0.0;
//         return {bob_str, stats};
//     }

//     GrammarTree tree_alice = build_hierarchical_lcp(alice_str);
//     GrammarTree tree_bob   = build_hierarchical_lcp(bob_str);

//     stats.bits_exchanged += 64;

//     size_t n = std::max(alice_str.size(), bob_str.size());
//     double log_n = std::max(2.0, std::log2(static_cast<double>(n)));

//     double mult = 1.0;
//     int final_status = 0;
//     std::string final_reconstructed = bob_str;

//     for (int retry = 0; retry <= 3; ++retry) {
//         size_t capacity = std::max<size_t>(32, static_cast<size_t>(16 * estimated_k * mult));

//         IBLT t_alice(capacity);
//         IBLT t_bob(capacity);

//         for (const auto& [rule_id, rule] : tree_alice.rules) {
//             t_alice.insert(rule_id);
//         }
//         for (const auto& [rule_id, rule] : tree_bob.rules) {
//             t_bob.insert(rule_id);
//         }

//         stats.bits_exchanged += t_alice.size() * (64 + 32);

//         IBLT t_delta = t_alice - t_bob;
//         std::set<uint64_t> peeled_rule_ids;
//         bool decode_ok = t_delta.listEntries(peeled_rule_ids);

//         if (decode_ok) {
//             stats.decoded_chunks = peeled_rule_ids.size();
//             std::unordered_map<uint64_t, GrammarRule> merged_rules = tree_bob.rules;

//             for (uint64_t rule_id : peeled_rule_ids) {
//                 auto it = tree_alice.rules.find(rule_id);
//                 if (it != tree_alice.rules.end()) {
//                     merged_rules[rule_id] = it->second;
//                     size_t rule_bits = 64 + (it->second.rhs.size() * 64) + (it->second.leaf_content.size() * 8);
//                     stats.bits_exchanged += rule_bits;
//                 }
//             }

//             std::string reconstructed = recursively_reconstruct(tree_alice.root_id, merged_rules);
//             if (reconstructed == alice_str) {
//                 final_reconstructed = reconstructed;
//                 final_status = 1;
//                 break;
//             } else {
//                 final_status = 2;
//             }
//         }
//         mult *= log_n;
//     }

//     if (final_status != 1) {
//         stats.bits_exchanged += alice_str.size() * 8;
//         final_reconstructed = alice_str;
//     }

//     stats.status = final_status;
//     auto end_time = std::chrono::high_resolution_clock::now();
//     stats.duration_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();

//     return {final_reconstructed, stats};
// }
