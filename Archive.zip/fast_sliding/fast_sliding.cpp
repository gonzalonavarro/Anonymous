#include "fast_sliding.h"
#include <algorithm>

inline int floor_log2_u64(uint64_t x) {
    return 63 - __builtin_clzll(x);
}

// SLIDE 2: Binary search slide using rolling hashes
int slide(const RollingHash &hx, const RollingHash &hy, int d, int i, int n, int m) {
    int lo = i, hi = min(n, m - d);  // diagonal bounds
    while (lo < hi) {
        int mid = (lo + hi + 1) / 2;
        if (hx.hash(i, mid) == hy.hash(i + d, mid + d))
            lo = mid;
        else
            hi = mid - 1;
    }
    return lo;
}

// SLIDE 1: Simple character-by-character slide
// Returns farthest row reached on diagonal d from starting row i_max
// Runs in O(n) in worst case
// int slide(const string &x, const string &y, int d, int i_max) {
//     int n = x.size(), m = y.size();
//     while (i_max < n && i_max + d < m && i_max + d >= 0 && x[i_max] == y[i_max + d]) {
//         i_max++;
//     }
//     return i_max;
// }


// Edit distance with max distance k
// Returns edit distance if <= k, else -1
// Runs in O(k^2) time + O(n) slide subroutine and O(k) space
tuple<int, size_t> fast_sliding_algorithm(const string &x, const string &y, int k) {
    int n = x.size(), m = y.size();
    ++k; // Adjust k to be at least the length difference

    RollingHash hx(x), hy(y); // O(n) preprocessing for rolling hashes
    const int HASH_BITS = 64;
    size_t total_bits = 0;

    // M[d + k]  = farthest row on diagonal d
    vector<int> M_prev(2*k + 1, -1); // M_h-1 wave
    vector<int> M_curr(2*k + 1, -1); // M_h wave

    // Base case: d = 0, h = 0
    // M_curr[k] = slide(x, y, 0, 0); // Slide along diagonal 0 from row 0
    // M_curr[k] = slide(hx, hy, 0, 0, n, m);
    // total_bits += HASH_BITS * ceil(log2(n));

    // Base case: slide along diagonal 0 from row 0
    {
        int d = 0;
        int i = 0;
        int hi = min(n, m - d);
        int comps = (hi > i) ? floor_log2_u64(hi - i) + 1 : 0;
        total_bits += HASH_BITS * comps;

        M_curr[k] = slide(hx, hy, d, i, n, m);
    }

    if (M_curr[k] >= n && M_curr[k] >= m) {
        return {0, total_bits}; // Strings are identical
    }
    M_prev = M_curr;

    // Compute waves h = 1 to k
    for (int h = 1; h <= k; ++h) {
        // Compute M_h for current wave h
        for (int d = -h; d <= h; ++d) {
            int idx = d + k; // Shift index by k to handle negative d
            
            // Check if we have already reached the end of both strings
            if (M_curr[idx] >= n && M_curr[idx] + d >= m) {
                return {h - 1, total_bits}; // Edit distance found
            }

            int i_max = -1; // starting row for sliding

            // insertion in x (d+1)
            if (d < h-1) {
                i_max = max(i_max, M_prev[idx+1] + 1);
            }

            // substitution or match (d)
            if (d > -h && d < h) {
                i_max = max(i_max, M_prev[idx] + 1);
            }

            // insertion in y (d-1)
            if (d > -h+1) {
                i_max = max(i_max, M_prev[idx-1]);
            }

            if (i_max < 0) i_max = 0;

            int hi = min(n, m - d);
            int comps = (hi > i_max) ? floor_log2_u64(hi - i_max) + 1 : 0;
            total_bits += HASH_BITS * comps;
            
            M_curr[idx] = slide(hx, hy, d, i_max, n, m);
        }

        // cout << "\nAfter wave " << h << ": ";
        // for (int d = -h; d <= h; ++d) {
        //     int idx = d + k; 
        //     cout << "d=" << d << "->" << M_curr[idx] << " ";
        // }

        M_prev = M_curr;
    }

    return {-1, total_bits}; // Edit distance > k
}