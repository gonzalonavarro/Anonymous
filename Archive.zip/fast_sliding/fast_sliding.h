#ifndef FAST_SLIDING_H
#define FAST_SLIDING_H

#include <string>
#include <vector>

using namespace std;

struct RollingHash {
    std::vector<uint64_t> prefix, power;
    static const uint64_t base = 1315423911ULL;

    // Precompute prefix hashes and powers of base in O(n) time
    RollingHash(const std::string &s){
        // int n = static_cast<int>(s.size());
        prefix.resize(s.size() + 1, 0); // prefix[i] = hash of s[0..i-1]
        power.resize(s.size() + 1, 1); // power[i] = base^i

        for (size_t i = 0; i < s.size(); i++) {
            prefix[i+1] = prefix[i] * base + s[i];
            power[i+1] = power[i] * base;
        }
    }
    uint64_t hash(int l, int r) const {
        return prefix[r] - prefix[l] * power[r - l];
    }
};

// Returns farthest row reached on diagonal d from starting row i_max
// Runs in O(n) in worst case
int slide(const RollingHash &hx, const RollingHash &hy, int d, int i_max, int n, int m);

// Edit distance with max distance k
// Returns edit distance if <= k, else -1
// Runs in O(k^2) time + O(n) slide subroutine and O(k) space
tuple<int, size_t> fast_sliding_algorithm(const string &x, const string &y, int k);

#endif 