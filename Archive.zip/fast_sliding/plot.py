from pathlib import Path
import csv
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    "font.size": 12,
    "axes.labelsize": 12,
    "axes.titlesize": 14,
    "legend.fontsize": 10,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10
})

def calc_r2(y_true, y_pred):
    ss_res = np.sum((y_true - y_pred)**2)
    ss_tot = np.sum((y_true - np.mean(y_true))**2)
    if ss_tot == 0: 
        return 1.0
    return 1 - (ss_res / ss_tot)

def load_comparison_data(csv_file):
    data = {'x': [], 's_bm': [], 's_bs': [], 's_tm': [], 's_ts': [],
            'e_bm': [], 'e_bs': [], 'e_tm': [], 'e_ts': []}
    with open(csv_file, newline='') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            print(f"Warning: {csv_file} is empty. Skipping.")
            return None
        x_col = 'k' if 'k' in reader.fieldnames else 'n'
        for row in reader:
            data['x'].append(float(row[x_col]))
            data['s_bm'].append(float(row['synth_b_mean']))
            data['s_bs'].append(float(row['synth_b_std']))
            data['s_tm'].append(float(row['synth_t_mean']))
            data['s_ts'].append(float(row['synth_t_std']))
            data['e_bm'].append(float(row['ecoli_b_mean']))
            data['e_bs'].append(float(row['ecoli_b_std']))
            data['e_tm'].append(float(row['ecoli_t_mean']))
            data['e_ts'].append(float(row['ecoli_t_std']))
    return {k: np.array(v) for k, v in data.items()}

def plot_combined_with_fits(x, y_synth, err_synth, y_ecoli, err_ecoli, 
                            xlabel, ylabel, title, filename, 
                            fit_type_synth='powerlaw', fit_type_ecoli='powerlaw', 
                            threshold=None, x_sym='x'):
    plt.figure(figsize=(8, 5))
    
    # Plot Observed Data
    plt.errorbar(x, y_synth, yerr=err_synth, fmt='o', markersize=6, 
                 color='steelblue', ecolor='lightsteelblue', capsize=3, label='Synthetic Data')
    
    plt.errorbar(x, y_ecoli, yerr=err_ecoli, fmt='s', markersize=6, 
                 color='mediumvioletred', ecolor='palevioletred', capsize=3, label='E. coli Data')

    # General fitting application logic
    def apply_fit(x_data, y_data, color, label_prefix, linestyle, fit_type, thresh):
        mask = (x_data > 0) & (y_data > 0)
        if not np.any(mask):
            return
        x_f, y_f = x_data[mask], y_data[mask]

        if fit_type == 'powerlaw':
            slope, intercept = np.polyfit(np.log(x_f), np.log(y_f), 1)
            C = np.exp(intercept)
            fit = C * x_data**slope
            r2 = calc_r2(np.log(y_f), np.log(fit[mask]))
            plt.plot(x_data, fit, linestyle=linestyle, color=color, alpha=0.7,
                     label=rf'{label_prefix} Fit: ${C:.2e} \cdot {x_sym}^{{{slope:.2f}}}$, $R^2={r2:.3f}$')

        elif fit_type == 'powerlaw_large':
            if thresh is None: thresh = 2**10
            large_mask = x_f >= thresh
            if np.any(large_mask):
                x_large, y_large = x_f[large_mask], y_f[large_mask]
                slope, intercept = np.polyfit(np.log(x_large), np.log(y_large), 1)
                C = np.exp(intercept)
                
                x_large_plot = x_data[x_data >= thresh]
                fit = C * x_large_plot**slope
                r2 = calc_r2(np.log(y_large), np.log(fit))
                
                plt.plot(x_large_plot, fit, linestyle=linestyle, color=color, alpha=0.7,
                         label=rf'{label_prefix} Fit (${x_sym} \geq {thresh}$): ${C:.2e} \cdot {x_sym}^{{{slope:.2f}}}$, $R^2={r2:.3f}$')

        elif fit_type == 'linear':
            slope, intercept = np.polyfit(x_f, y_f, 1)
            fit = slope * x_data + intercept
            fit_plot = np.maximum(fit, 1e-9) 
            r2 = calc_r2(y_f, fit[mask])
            plt.plot(x_data, fit_plot, linestyle=linestyle, color=color, alpha=0.7,
                     label=rf'{label_prefix} Fit: ${slope:.2e} \cdot {x_sym} {intercept:+.2e}$, $R^2={r2:.3f}$')

        elif fit_type == 'log_linear_large':
            if thresh is None: thresh = 2**10
            large_mask = x_f >= thresh
            if np.any(large_mask):
                x_large, y_large = x_f[large_mask], y_f[large_mask]
                slope, intercept = np.polyfit(np.log2(x_large), y_large, 1)
                
                x_large_plot = x_data[x_data >= thresh]
                fit = slope * np.log2(x_large_plot) + intercept
                fit = np.maximum(fit, 1e-9)
                r2 = calc_r2(y_large, fit)
                
                plt.plot(x_large_plot, fit, linestyle=linestyle, color=color, alpha=0.7,
                         label=rf'{label_prefix} Fit (${x_sym} \geq {thresh}$): ${slope:.2f} \log_2({x_sym}) {intercept:+.2f}$, $R^2={r2:.3f}$')

    # Apply fits
    apply_fit(x, y_synth, 'steelblue', 'Synth', '--', fit_type_synth, threshold)
    apply_fit(x, y_ecoli, 'mediumvioletred', 'E. coli', '-.', fit_type_ecoli, threshold)

    plt.xscale('log', base=2)
    plt.yscale('log', base=2)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True, which='both', linestyle='--', alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()

if __name__ == '__main__':
    data_folder = Path("data")
    
    # 1. Plot Fixed Size (Varying k)
    file_k = data_folder / "compare_fix_size.csv"
    if file_k.exists():
        d = load_comparison_data(file_k)
        if d is not None:
            # Runtime vs k (Powerlaw starting at k=128)
            plot_combined_with_fits(d['x'], d['s_tm'], d['s_ts'], d['e_tm'], d['e_ts'], 
                                    'k (Number of edits)', 'Runtime (ms)', 
                                    'Runtime vs k (Fixed N = 1,048,576)', 
                                    data_folder / 'comparison_runtime_vs_k.png',
                                    fit_type_synth='powerlaw_large', fit_type_ecoli='powerlaw_large', 
                                    threshold=2**8, x_sym='k')
                          
            # Bits vs k (Powerlaw for both)
            plot_combined_with_fits(d['x'], d['s_bm'], d['s_bs'], d['e_bm'], d['e_bs'], 
                                    'k (Number of edits)', 'Bits sent', 
                                    'Bits Sent vs k (Fixed N = 1,048,576)', 
                                    data_folder / 'comparison_bits_vs_k.png',
                                    fit_type_synth='powerlaw', fit_type_ecoli='powerlaw',
                                    x_sym='k')

    # 2. Plot Fixed k (Varying N)
    file_n = data_folder / "compare_fix_k.csv"
    if file_n.exists():
        d = load_comparison_data(file_n)
        if d is not None:
            # Runtime vs N (Powerlaw starting at N=2048)
            plot_combined_with_fits(d['x'], d['s_tm'], d['s_ts'], d['e_tm'], d['e_ts'], 
                                    'Sequence Length n (bytes)', 'Runtime (ms)', 
                                    'Runtime vs Sequence Length n (Fixed k = 32)', 
                                    data_folder / 'comparison_runtime_vs_n.png',
                                    fit_type_synth='powerlaw_large', fit_type_ecoli='powerlaw_large', 
                                    threshold=2**15, x_sym='n')
                          
            # Bits vs N (Log for both, starting at threshold 2^10)
            plot_combined_with_fits(d['x'], d['s_bm'], d['s_bs'], d['e_bm'], d['e_bs'], 
                                    'Sequence Length n (bytes)', 'Bits sent', 
                                    'Bits Sent vs Sequence Length n (Fixed k = 32)', 
                                    data_folder / 'comparison_bits_vs_n.png',
                                    fit_type_synth='log_linear_large', fit_type_ecoli='log_linear_large', 
                                    threshold=2**10, x_sym='n')
