#include "fast_sliding.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <utility>
#include <fstream>
#include <ctime>
#include <chrono>
#include <cstdlib>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <cctype>
#include <string>
#include <filesystem>

using namespace std;

const string ALPHABET_DNA = "ACGT";
const string ALPHABET_RANDOM = "abcdefghijklmnopqrstuvwxyz";

// -----------------------
// Test case structure
// -----------------------
struct TestCase {
    string x;
    string y;
    int k;
    int expected;
    string description;
};

// ANSI color codes
const string GREEN = "\033[32m";
const string RED   = "\033[31m";
const string YELLOW= "\033[33m";
const string BLUE  = "\033[36m";
const string RESET = "\033[0m";

// -----------------------
// Helper: Ensure output directory exists
// -----------------------
void ensure_data_directory() {
    filesystem::create_directories("data");
}

// -----------------------
// Statistics Helpers
// -----------------------
static double calc_mean(const vector<double>& v) {
    if (v.empty()) return 0.0;
    return accumulate(v.begin(), v.end(), 0.0) / v.size();
}

static double calc_stddev(const vector<double>& v, double mean) {
    if (v.size() <= 1) return 0.0;
    double sq_sum = 0.0;
    for (double x : v) sq_sum += (x - mean) * (x - mean);
    return sqrt(sq_sum / (v.size() - 1));
}

// -----------------------
// FASTA Loader
// -----------------------
static string load_fasta_sequence(const string& filepath) {
    ifstream file(filepath);
    if (!file.is_open()) {
        cerr << "Failed to open FASTA file: " << filepath << "\n";
        return "";
    }

    string sequence;
    string line;
    while (getline(file, line)) {
        if (line.empty() || line[0] == '>' || line[0] == ';') continue;
        line.erase(remove_if(line.begin(), line.end(), [](unsigned char c) {
            return isspace(c);
        }), line.end());
        transform(line.begin(), line.end(), line.begin(), ::toupper);
        sequence += line;
    }
    return sequence;
}

// -----------------------
// Random string generator
// -----------------------
string random_string(size_t n, const string& alphabet = ALPHABET_RANDOM) {
    string s(n, ' ');
    for (size_t i = 0; i < n; i++)
        s[i] = alphabet[rand() % alphabet.size()];
    return s;
}

// -----------------------
// Generate string with k edits
// -----------------------
string generate_with_edits(const string &x, int k, const string& alphabet = ALPHABET_RANDOM) {
    string y = x;
    for (int i = 0; i < k; i++) {
        int type = rand() % 3;
        int pos = rand() % (y.size() + 1);
        char c = alphabet[rand() % alphabet.size()];

        if (type == 0 && !y.empty())
            y[min(pos, (int)y.size()-1)] = c;     // Substitution
        else if (type == 1)
            y.insert(y.begin() + pos, c);         // Insertion
        else if (type == 2 && !y.empty())
            y.erase(y.begin() + min(pos, (int)y.size()-1)); // Deletion
    }
    return y;
}

// -----------------------
// Run single test
// -----------------------
void runTest(const TestCase &test, int testNum) {
    auto [edit_dist, bits_sent] = fast_sliding_algorithm(test.x, test.y, test.k);
    bool passed = (edit_dist == test.expected);

    cout << BLUE << "Test " << testNum << ": " << RESET << test.description << "\n";
    cout << "  x = \"" << test.x << "\", y = \"" << test.y << "\", k = " << test.k << "\n";
    cout << "  Expected: " << test.expected << ", Got: " << edit_dist << "\n";
    cout << "  Bits sent: " << bits_sent << "\n";
    cout << (passed ? GREEN + " ✓ PASSED" : RED + " ✗ FAILED") << RESET << "\n\n";
}

// -----------------------
// Run all correctness unit tests
// -----------------------
int test_fast_sliding(){
    vector<TestCase> tests = {
        {"", "", 0, 0, "Empty strings"},
        {"a", "a", 1, 0, "Identical single character"},
        {"abc", "abc", 3, 0, "Identical strings"},
        {"abc", "abcde", 5, 2, "m > n: y is longer"},
        {"", "abc", 5, 3, "Empty x, non-empty y"},
        {"a", "abcd", 5, 3, "Short x, long y"},
        {"abcde", "abc", 5, 2, "n > m: x is longer"},
        {"abc", "", 5, 3, "Non-empty x, empty y"},
        {"abc", "ab", 2, 1, "Single deletion"},
        {"ab", "abc", 2, 1, "Single insertion"},
        {"abc", "adc", 2, 1, "Single substitution"},
        {"kitten", "sitting", 10, 3, "Classic edit"},
        {"saturday", "sunday", 10, 3, "Complex edit"},
        {"abc", "xyz", 1, -1, "Distance > k"},
        {"hello", "world", 2, -1, "Distance > k 2"},
        {"abc", "def", 3, 3, "All substitutions"},
        {"abc", "def", 2, -1, "All substitutions > k"},
        {"algorithm", "altruistic", 10, 6, "Long strings"},
        {"exponential", "polynomial", 15, 6, "Transformation"},
        {"prefix_abc", "prefix_xyz", 5, 3, "Common prefix"},
        {"abc_suffix", "xyz_suffix", 5, 3, "Common suffix"},
        {"aaaa", "bbbb", 5, 4, "Complete mismatch"},
        {"a", "b", 1, 1, "Single substitution"},
        {"", "a", 1, 1, "Insert"},
        {"a", "", 1, 1, "Delete"},
        {"aaaa", "aaa", 2, 1, "Deletion repeated"},
        {"aaa", "aaaa", 2, 1, "Insertion repeated"},
        {"color", "colour", 2, 1, "US vs UK"},
        {"organize", "organise", 2, 1, "US vs UK 2"}
    };

    cout << "\n========================================\n";
    cout << "  FAST SLIDING ALGORITHM TESTS\n";
    cout << "========================================\n\n";

    int passed = 0, failed = 0;
    for (size_t i = 0; i < tests.size(); ++i) {
        runTest(tests[i], i + 1);
        auto [edit_dist, bits_sent] = fast_sliding_algorithm(tests[i].x, tests[i].y, tests[i].k);
        if (edit_dist == tests[i].expected) passed++;
        else failed++;
    }

    cout << "========================================\n";
    cout << "  SUMMARY\n";
    cout << "========================================\n";
    cout << "Total tests: " << tests.size() << "\n";
    cout << GREEN << "Passed: " << passed << RESET << "\n";
    cout << RED << "Failed: " << failed << RESET << "\n";
    cout << "========================================\n\n";

    return (failed == 0) ? 0 : 1;
}

// -----------------------
// Unified Experiment Helper
// -----------------------
void run_experiment(const string& x, int k, int trials, const string& alphabet, double& t_mean, double& t_std, double& b_mean, double& b_std) {
    vector<double> times;
    vector<double> bits;
    
    for (int r = 0; r < trials; r++) {
        string y = generate_with_edits(x, k, alphabet);
        auto start = chrono::steady_clock::now();
        auto [edit_dist, bits_sent] = fast_sliding_algorithm(x, y, k * 2);
        auto end = chrono::steady_clock::now();

        if (edit_dist != -1) {
            times.push_back(chrono::duration<double, milli>(end - start).count());
            bits.push_back((double)bits_sent);
        }
    }
    
    b_mean = calc_mean(bits);
    b_std = calc_stddev(bits, b_mean);
    t_mean = calc_mean(times);
    t_std = calc_stddev(times, t_mean);
}

// -----------------------
// Unified Test 1: Fixed Size, Varying k
// -----------------------
void run_comparison_fix_size(const string& full_ecoli, size_t n, int max_k) {
    string filename = "data/compare_fix_size.csv";
    ofstream fout(filename);
    fout << "k,synth_b_mean,synth_b_std,synth_t_mean,synth_t_std,ecoli_b_mean,ecoli_b_std,ecoli_t_mean,ecoli_t_std\n";

    string ecoli_base = full_ecoli.substr(0, min(n, full_ecoli.size()));
    string synth_base = random_string(ecoli_base.size(), ALPHABET_RANDOM);
    int trials = 10;

    cout << "\n--- Fixed Size N=" << ecoli_base.size() << ", Varying k ---\n";
    for (int k = 1; k <= max_k; k *= 2) {
        double s_tm, s_ts, s_bm, s_bs;
        double e_tm, e_ts, e_bm, e_bs;

        run_experiment(synth_base, k, trials, ALPHABET_RANDOM, s_tm, s_ts, s_bm, s_bs);
        run_experiment(ecoli_base, k, trials, ALPHABET_DNA, e_tm, e_ts, e_bm, e_bs);

        fout << k << "," << s_bm << "," << s_bs << "," << s_tm << "," << s_ts << ","
             << e_bm << "," << e_bs << "," << e_tm << "," << e_ts << "\n";

        cout << "k=" << setw(5) << k 
             << " | Synth Time: " << fixed << setprecision(2) << s_tm << "ms | Ecoli Time: " << e_tm << "ms\n";
    }
    fout.close();
}

// -----------------------
// Unified Test 2: Fixed k, Varying Sequence Length N
// -----------------------
void run_comparison_fix_k(const string& full_ecoli, size_t max_n, int k) {
    string filename = "data/compare_fix_k.csv";
    ofstream fout(filename);
    fout << "n,synth_b_mean,synth_b_std,synth_t_mean,synth_t_std,ecoli_b_mean,ecoli_b_std,ecoli_t_mean,ecoli_t_std\n";
    int trials = 10;

    cout << "\n--- Fixed k=" << k << ", Varying Size N ---\n";
    for (size_t n = 64; n <= max_n; n *= 2) {
        if (n > full_ecoli.size()) break;

        string ecoli_base = full_ecoli.substr(0, n);
        string synth_base = random_string(n, ALPHABET_RANDOM);

        double s_tm, s_ts, s_bm, s_bs;
        double e_tm, e_ts, e_bm, e_bs;

        run_experiment(synth_base, k, trials, ALPHABET_RANDOM, s_tm, s_ts, s_bm, s_bs);
        run_experiment(ecoli_base, k, trials, ALPHABET_DNA, e_tm, e_ts, e_bm, e_bs);

        fout << n << "," << s_bm << "," << s_bs << "," << s_tm << "," << s_ts << ","
             << e_bm << "," << e_bs << "," << e_tm << "," << e_ts << "\n";

        cout << "N=" << setw(8) << n 
             << " | Synth Time: " << fixed << setprecision(2) << s_tm << "ms | Ecoli Time: " << e_tm << "ms\n";
    }
    fout.close();
}

// -----------------------
// Main Execution
// -----------------------
int main() {
    srand(time(nullptr));
    ensure_data_directory();

    int result = test_fast_sliding();

    string alice_file = "data/ecoli_variations/ecoli_normalized_base.fasta";
    string full_ecoli = load_fasta_sequence(alice_file);
    
    if (full_ecoli.empty()) {
        cerr << "Failed to load base E. coli genome. Ensure " << alice_file << " exists.\n";
        return 1;
    }

    run_comparison_fix_size(full_ecoli, 1 << 20, 1 << 15); 
    run_comparison_fix_k(full_ecoli, 1 << 24, 32);

    return result;
}
